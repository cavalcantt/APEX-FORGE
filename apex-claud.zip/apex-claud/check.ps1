$errs = $null
[System.Management.Automation.Language.Parser]::ParseFile('c:\Users\Cavalcanti\Desktop\apex-claud\server.ps1', [ref]$null, [ref]$errs)
if ($errs) {
    $errs | ForEach-Object { "$($_.Extent.StartLineNumber): $($_.Message)" }
} else {
    "OK"
}
