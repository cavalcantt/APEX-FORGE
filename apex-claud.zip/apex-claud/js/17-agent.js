// APEX FORGE - Agente incremental local
function parseApexTargetFromPrompt(msg){
  const pageMatch = msg.match(/\b(?:tela|p[áa]gina|pagina|page|p)\s*(?:=|:|n[ºo]\.?)?\s*(\d{1,5})\b/i);
  const appMatch  = msg.match(/\b(?:aplica[cç][aã]o|aplicacao|app|application)\s*(?:=|:)?\s*(\d{3,8})\b/i);
  return {
    page: pageMatch ? pageMatch[1] : '',
    appId: appMatch ? appMatch[1] : ''
  };
}

function applyPromptTargetToConfig(msg){
  const target = parseApexTargetFromPrompt(msg);
  if(target.page) document.getElementById('cfgPage').value = target.page;
  if(target.appId) document.getElementById('cfgApp').value = target.appId;
  return target;
}

function detectIncrementalIntent(msg){
  const lower = msg.toLowerCase();
  if(/\b(css|label|rotulo|r[oó]tulo|esconder|ocultar|hide)\b/i.test(lower) && /\b(label|rotulo|r[oó]tulo)\b/i.test(lower)){
    return 'hide_label_css';
  }
  if(/\b(multifiltro|multi filtro|filtro m[uú]ltiplo|csmultifiltro)\b/i.test(lower)){
    return 'multifiltro';
  }
  if(/\b(bot[aã]o|button|btn_[a-z0-9_]+|adicionar botao|coloque um botao)\b/i.test(lower)){
    return 'button';
  }
  return '';
}

function shouldUseLocalIncrementalAgent(msg, mode){
  if(mode !== 'local') return false;
  if(genMode === 'incr') return ['button', 'multifiltro'].includes(detectIncrementalIntent(msg));
  const target = parseApexTargetFromPrompt(msg);
  return !!(target.page && target.appId && ['button', 'multifiltro'].includes(detectIncrementalIntent(msg)));
}

function normalizeApexName(value){
  return (value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .toUpperCase();
}

function humanLabelFromName(name){
  return normalizeApexName(name)
    .replace(/^BTN_/, '')
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase());
}

function cleanPromptEntityName(value){
  return (value || '')
    .replace(/\b(?:na|no|da|do)?\s*(?:tela|p[áa]gina|pagina|page|app|aplica[cç][aã]o|aplicacao|application)\b[\s\S]*$/i, '')
    .replace(/\b(?:usando|com\s+query|com\s+tabela|tabela|owner|schema|cod|codigo|c[oó]digo|descricao|descri[cç][aã]o)\b[\s\S]*$/i, '')
    .replace(/[.,;:]+$/g, '')
    .trim();
}

function extractButtonSpec(msg, page){
  const explicit = msg.match(/\b(BTN_[A-Z0-9_]+)\b/i)?.[1];
  const labelMatch = msg.match(/(?:bot[aã]o|button)\s+(?:chamado|com\s+label|label|nomeado|de)?\s*["']?([A-Za-zÀ-ú0-9 _-]{3,40})["']?/i);
  const rawLabel = explicit ? humanLabelFromName(explicit) : (cleanPromptEntityName(labelMatch?.[1]) || 'Novo Botao');
  const name = explicit ? normalizeApexName(explicit) : 'BTN_' + normalizeApexName(rawLabel || 'NOVO_BOTAO');
  const icon = msg.match(/\bfa-[a-z0-9-]+\b/i)?.[0] || (/(export|baixar|download)/i.test(msg) ? 'fa-download' : 'fa-plus');
  const position = msg.match(/\b(COPY|NEXT|PREVIOUS|BELOW_BOX|BODY)\b/i)?.[1]?.toUpperCase() || 'NEXT';
  return { name, label: rawLabel, icon, position, page };
}

function extractMultifiltroSpec(msg, page, schema){
  const explicit = msg.match(/\bP\d+_[A-Z0-9_]+\b/i)?.[0];
  const nameMatch = msg.match(/(?:multifiltro|multi filtro|filtro)\s+(?:de|para|chamado)?\s*["']?([A-Za-zÀ-ú0-9 _-]{3,40})["']?/i);
  const rawName = explicit
    ? explicit.replace(/^P\d+_/i, '')
    : (cleanPromptEntityName(nameMatch?.[1]) || 'Filtro');
  const item = explicit ? explicit.toUpperCase() : `P${page}_${normalizeApexName(rawName)}`;
  const label = humanLabelFromName(rawName);
  const tableMatch = msg.match(/\b([A-Za-z][A-Za-z0-9_]{1,29})\.([A-Za-z][A-Za-z0-9_]{1,29})\b/);
  const owner = tableMatch ? tableMatch[1].toUpperCase() : schema.toUpperCase();
  const table = tableMatch ? tableMatch[2].toUpperCase() : 'TABELA';
  const cod = normalizeApexName(msg.match(/\b(?:codigo|c[oó]digo|cod)\s+([A-Za-z0-9_]+)/i)?.[1] || 'CODIGO');
  const desc = normalizeApexName(msg.match(/\b(?:descricao|descri[cç][aã]o|desc)\s+([A-Za-z0-9_]+)/i)?.[1] || 'DESCRICAO');
  return { item, label, owner, table, cod, desc, page };
}

function extractPageItemsFromPrompt(msg, page){
  const explicit = [...new Set((msg.match(/\bP\d+_[A-Z0-9_]+\b/gi) || []).map(x => x.toUpperCase()))];
  if(explicit.length) return explicit;

  const chunk = msg.match(/(?:itens?|items?)\s+([A-Za-zÀ-ú0-9_,\s-]+)/i)?.[1]
             || msg.match(/(?:label|rotulo|r[oó]tulo)\s+(?:do|dos|de|das)?\s*([A-Za-zÀ-ú0-9_,\s-]+)/i)?.[1]
             || '';

  const clean = chunk
    .replace(/\b(?:na|no|da|do)?\s*(?:tela|p[áa]gina|pagina|app|aplica[cç][aã]o|aplicacao)\b[\s\S]*$/i, '')
    .replace(/\b(?:com|usando|css|para|esconder|ocultar|hide)\b[\s\S]*$/i, '')
    .trim();

  return [...new Set(clean
    .split(/,| e |\s+/i)
    .map(x => normalizeApexName(x))
    .filter(x => x.length > 1)
    .map(x => x.match(/^P\d+_/) ? x : `P${page}_${x}`))];
}

function sqlLinesForApex(lines){
  return lines.map(line => `'${line.replace(/'/g, "''")}',`).join('\n');
}

function incrementalHeader(appId, schema, page, includeFilterRegion){
  return `DECLARE
  v_ws     NUMBER;
  v_base   NUMBER;
${includeFilterRegion ? '  v_filter_region_id NUMBER;\n' : ''}BEGIN
  SELECT workspace_id
    INTO v_ws
    FROM apex_applications
   WHERE application_id = ${appId};

  v_base := TO_NUMBER(TO_CHAR(SYSTIMESTAMP,'YYYYMMDDHH24MISSFF3'));

${includeFilterRegion ? `  BEGIN
    SELECT region_id
      INTO v_filter_region_id
      FROM apex_application_page_regions
     WHERE application_id = ${appId}
       AND page_id = ${page}
       AND UPPER(region_name) IN ('FILTROS', 'FILTRO')
     FETCH FIRST 1 ROW ONLY;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      SELECT region_id
        INTO v_filter_region_id
        FROM apex_application_page_regions
       WHERE application_id = ${appId}
         AND page_id = ${page}
       ORDER BY display_sequence NULLS LAST, region_id
       FETCH FIRST 1 ROW ONLY;
  END;

` : ''}  wwv_flow_imp.import_begin(
    p_version_yyyy_mm_dd     => '2024.05.31',
    p_release                => '24.1.0',
    p_default_workspace_id   => v_ws,
    p_default_application_id => ${appId},
    p_default_id_offset      => 0,
    p_default_owner          => '${schema}'
  );
`;
}

function incrementalFooter(){
  return `
  wwv_flow_imp.import_end(
    p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj,false)
  );
  commit;
END;
/`;
}

function generateIncrementalButtonSQL(msg, page, schema, appId){
  const spec = extractButtonSpec(msg, page);
  const tmpl = getTemplates(appId);
  const sql = incrementalHeader(appId, schema, page, true) + `
  wwv_flow_imp_page.create_page_button(
    p_id                       => v_base,
    p_button_sequence          => 100,
    p_button_plug_id           => v_filter_region_id,
    p_button_name              => '${spec.name}',
    p_button_action            => 'DEFINED_BY_DA',
    p_button_template_options  => '#DEFAULT#:t-Button--hot:t-Button--iconLeft',
    p_button_template_id       => wwv_flow_imp.id(${tmpl.btn_icon || tmpl.btn_no_icon}),
    p_button_is_hot            => 'Y',
    p_button_image_alt         => '${spec.label.replace(/'/g, "''")}',
    p_button_position          => '${spec.position}',
    p_icon_css_classes         => '${spec.icon}'
  );
` + incrementalFooter();

  return {
    sql,
    response: `Botao <b>${spec.name}</b> preparado para a pagina <b>${page}</b> do app <b>${appId}</b>.<br>Ele sera criado na regiao <b>Filtros</b> usando SQL incremental.`
  };
}

function generateIncrementalMultifiltroSQL(msg, page, schema, appId){
  const spec = extractMultifiltroSpec(msg, page, schema);
  const tmpl = getTemplates(appId);
  const lov = [
    `SELECT ${spec.cod} || ' - ' || ${spec.desc} AS D,`,
    `       ${spec.cod} AS R,`,
    `       ${spec.cod} AS CODIGO,`,
    `       ${spec.desc} AS DESCRICAO`,
    `  FROM ${spec.owner}.${spec.table}`,
    ` WHERE 1 = 1`,
    `   AND cod_grupoempresa = :G_COD_GRUPOEMPRESA`,
    `   AND cod_empresa      = :G_COD_EMPRESA`,
    `   AND cod_filial       = :G_COD_FILIAL`,
    ` ORDER BY 1`
  ];
  const json = '{"defaultSort":{"column":"CODIGO","direction":"asc"},"columns":{"CODIGO":{"heading":"Codigo","visible":true,"thAlign":"right","tdAlign":"right","width":"80px","sort":true,"filter":true},"DESCRICAO":{"heading":"Descricao","visible":true,"thAlign":"left","tdAlign":"left","sort":true,"filter":true}}}';
  const sql = incrementalHeader(appId, schema, page, true) + `
  wwv_flow_imp_page.create_page_item(
    p_id                       => v_base,
    p_name                     => '${spec.item}',
    p_item_sequence            => 100,
    p_item_plug_id             => v_filter_region_id,
    p_prompt                   => '${spec.label.replace(/'/g, "''")}',
    p_display_as               => 'PLUGIN_PL.OSTROWSKIBARTOSZ.APEX.ENHANCEDLOVITEM',
    p_lov                      => wwv_flow_string.join(wwv_flow_t_varchar2(
${sqlLinesForApex(lov)}
    '')),
    p_cSize                    => 30,
    p_begin_on_new_line        => 'N',
    p_field_template           => wwv_flow_imp.id(${tmpl.field_template}),
    p_item_template_options    => '#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large',
    p_lov_display_extra        => 'NO',
    p_attribute_01             => 'RS:LDT',
    p_attribute_04             => '%D%',
    p_attribute_05             => 'AUTOCOMPLETE:POPOUP_REPORT',
    p_attribute_06             => 'RCC:CORSI:DRAGGABLE:COE:RPP:SIAC',
    p_attribute_07             => '${json.replace(/'/g, "''")}',
    p_attribute_09             => '0',
    p_attribute_12             => '720',
    p_attribute_13             => '541',
    p_attribute_14             => '200',
    p_attribute_15             => '20',
    p_attribute_17             => '2'
  );
` + incrementalFooter();

  return {
    sql,
    response: `Multifiltro <b>${spec.item}</b> preparado para a pagina <b>${page}</b> do app <b>${appId}</b>.<br>A LOV usa <code>${spec.owner}.${spec.table}</code> e o padrao CSMultifiltro.`
  };
}

function generateLocalIncrementalSQL(msg, page, schema, appId){
  const intent = detectIncrementalIntent(msg);
  if(intent === 'button') return generateIncrementalButtonSQL(msg, page, schema, appId);
  if(intent === 'multifiltro') return generateIncrementalMultifiltroSQL(msg, page, schema, appId);
  return null;
}
