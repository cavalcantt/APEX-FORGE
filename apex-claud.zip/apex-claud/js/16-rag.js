// ── APEX FORGE — RAG / MCP (Retrieval-Augmented Generation) ──

// Busca contexto relevante na base de conhecimento para enriquecer o prompt da IA
async function ragSearch(query, top) {
  top = top || 4;
  try {
    const res = await fetch('http://localhost:3007/rag-search', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({ query, top }),
      signal: AbortSignal.timeout(1200)
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.success ? (data.results || []) : [];
  } catch (_) {
    return [];
  }
}

// Retorna contexto geral da aplicação (páginas, entries KB, SQL recentes)
async function mcpGetContext(appId) {
  try {
    const res = await fetch('http://localhost:3007/mcp-context', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({ appId: parseInt(appId) || 0 }),
      signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.success ? data.context : null;
  } catch (_) {
    return null;
  }
}

// Salva SQL bem-sucedido na memória RAG do servidor
async function ragStoreSucess(sql, page, appId, tags) {
  try {
    await fetch('http://localhost:3007/rag-store', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({ sql, page, appId, tags: tags || [] }),
      signal: AbortSignal.timeout(5000)
    });
  } catch (_) { /* silencioso */ }
}

// Monta o bloco de contexto RAG para injetar no system prompt
async function buildRagContext(userMessage) {
  if (!serverUp) return '';

  const results = await ragSearch(userMessage, 4);
  if (!results.length) return '';

  tlog(`RAG: ${results.length} entradas relevantes encontradas`, 'i');

  const block = results.map(r =>
    `### ${r.title}\n${r.content}`
  ).join('\n\n');

  return `\nCONHECIMENTO ESPECÍFICO DO PROJETO (use como referência prioritária):\n${block}\n`;
}

// Integração com buildSystemPrompt — sobrescreve para incluir RAG
// Guarda referência ao buildSystemPrompt original
const _buildSystemPromptOriginal = buildSystemPrompt;

function buildSystemPrompt(gl, page, schema, appId, group, enriched, ragContext) {
  const base = _buildSystemPromptOriginal(gl, page, schema, appId, group, enriched);
  if (!ragContext) return base;
  // Injeta o contexto RAG logo após as CONFIGURAÇÕES no prompt
  return base.replace(
    'FORMATO DA RESPOSTA:',
    `CONHECIMENTO ESPECÍFICO DO PROJETO (use como referência prioritária):\n${ragContext}\n\nFORMATO DA RESPOSTA:`
  );
}
