// ── APEX FORGE — Enrich ──
async function autoEnrichContext(msg, defaultSchema, defaultApp) {
  if (!serverUp) {
    return { tables: [], pageSql: null, detectedPage: null };
  }

  const tables   = [];
  const fetched  = new Set();

  // ── 1. Detecta owner.tabela (ex: agricola.talhao) ──
  const dotPattern = /\b([A-Za-z][A-Za-z0-9_]{1,29})\.([A-Za-z][A-Za-z0-9_]{1,29})\b/g;
  const skipOwners = new Set(['WWV_FLOW','WWV_FLOW_IMP','APEX_APPLICATION','APEX_UTIL','SYS','SYSTEM',
    'PKG','CSWEB','NVL','CASE','WHEN','THEN','ELSE','END','NULL','FROM','WHERE','AND','OR','JOIN']);
  const skipTables = new Set(['G_FLOW','G_FLOW_ID','IMPORT_BEGIN','IMPORT_END','CREATE_PAGE',
    'REMOVE_PAGE','CREATE_PAGE_PLUG','CREATE_PAGE_ITEM','CREATE_PAGE_BUTTON',
    'CREATE_PAGE_DA_EVENT','CREATE_PAGE_DA_ACTION','CREATE_INTERACTIVE_GRID',
    'CREATE_IG_REPORT','CREATE_IG_REPORT_VIEW','CREATE_IG_REPORT_COLUMN','ID',
    'CREATE_REGION_COLUMN','CREATE_WORKSHEET','CREATE_WORKSHEET_COLUMN']);

  for (const m of msg.matchAll(dotPattern)) {
    const owner = m[1].toUpperCase();
    const tbl   = m[2].toUpperCase();
    if (skipOwners.has(owner) || skipTables.has(tbl)) continue;
    const key = `${owner}.${tbl}`;
    if (!fetched.has(key)) { fetched.add(key); tables.push({ owner, table: tbl }); }
  }

  // ── 2. Detecta "tabela X" ou "da tabela X" (sem owner) ──
  for (const m of msg.matchAll(/\b(?:da\s+tabela|tabela|table)\s+([A-Za-z][A-Za-z0-9_]{1,29})\b/gi)) {
    const tbl = m[1].toUpperCase();
    if (skipTables.has(tbl)) continue;
    const owner = defaultSchema.toUpperCase();
    const key   = `${owner}.${tbl}`;
    if (!fetched.has(key)) { fetched.add(key); tables.push({ owner, table: tbl }); }
  }

  // ── 3. Detecta referência a página APEX ──
  // Ex: "pagina 81 app 40154", "p81 app 255", "page 100 application 40154"
  let detectedPage = null;
  const isReferenceMode = /\b(?:referencia|refer[eê]ncia|modelo|igual|parecid[ao]|basead[ao])\b/i.test(msg)
                       || /\b(?:nova|criar|crie|gere|montar|monte)\s+(?:tela|pagina|p[áa]gina|page)\b/i.test(msg);
  const pgMatch  = msg.match(/\b(?:p[áa]gina|page|p\.?)\s*[=:]?\s*(\d{1,5})\b/i);
  const appMatch = msg.match(/\b(?:app(?:lica[çc][aã]o)?|application)\s*[=:]?\s*(\d{3,8})\b/i);

  if (pgMatch) {
    detectedPage = {
      pageId: pgMatch[1],
      appId:  appMatch ? appMatch[1] : defaultApp
    };
  }
  if (!detectedPage && typeof parseApexTargetFromPrompt === 'function') {
    const target = parseApexTargetFromPrompt(msg);
    if(target.page){
      detectedPage = { pageId: target.page, appId: target.appId || defaultApp };
    }
  }

  // ── Fetch schemas em batch ──
  const tableResults = [];
  if (tables.length) {
    tlog(`Auto-detect: tabelas encontradas — ${tables.map(t=>`${t.owner}.${t.table}`).join(', ')}`, 'i');
    
    // Filtra as que não estão no cache
    const toFetch = tables.filter(t => !schColumnsCache[`${t.owner}.${t.table}`]);
    const cached  = tables.filter(t => schColumnsCache[`${t.owner}.${t.table}`]);
    
    // Adiciona as cacheadas diretamente
    cached.forEach(t => {
      const key = `${t.owner}.${t.table}`;
      tlog(`Schema ${key} via cache`, 'i');
      tableResults.push({ owner: t.owner, table: t.table, columns: schColumnsCache[key] });
    });

    if (toFetch.length > 0) {
      try {
        tlog(`Buscando ${toFetch.length} tabelas no banco de uma vez...`, 'i');
        const res  = await fetch('http://localhost:3007/schema-columns-batch', {
          method: 'POST', headers: getForgeHeaders(),
          body: JSON.stringify({ tables: toFetch }), signal: AbortSignal.timeout(120000)
        });
        const data = await res.json();
        
        if (data.success && data.results) {
          Object.keys(data.results).forEach(key => {
            const cols = data.results[key];
            if (cols && cols.length) {
              const [o, t] = key.split('.');
              tlog(`✓ Schema ${key} — ${cols.length} colunas`, 's');
              schColumnsCache[key] = cols;
              tableResults.push({ owner: o, table: t, columns: cols });
            }
          });
        } else {
          tlog(`Nao foi possivel buscar algumas tabelas: ${data.error || 'Erro desconhecido'}`, 'w');
        }
      } catch(e) {
        tlog(`Falha no batch de schemas: ${e.message}`, 'w');
      }
    }

    // Atualiza Schema Explorer visual com a última encontrada
    if (tableResults.length) {
      const last = tableResults[tableResults.length - 1];
      schCurrentOwner = last.owner;
      schCurrentTable = last.table;
      schColumns      = last.columns;
    }
  }

  // ── Fetch página APEX ──
  let pageSql = null;
  if (detectedPage) {
    const pageCacheKey = `${detectedPage.appId}.${detectedPage.pageId}`;
    if(apexPageCache[pageCacheKey]){
      pageSql = apexPageCache[pageCacheKey].sql;
      document.getElementById('cfgPageSQL').value = pageSql;
      if(!isReferenceMode){
        document.getElementById('cfgApp').value   = detectedPage.appId;
        document.getElementById('cfgPage').value  = detectedPage.pageId;
        if (genMode !== 'incr') setGenMode('incr');
      }
      tlog(`Pagina App=${detectedPage.appId} Page=${detectedPage.pageId} via cache`, 'i');
      return { tables: tableResults, pageSql, detectedPage };
    }
  }
  if (detectedPage) {
    tlog(`Auto-detect: página App=${detectedPage.appId} Page=${detectedPage.pageId}`, 'i');
    try {
      const res  = await fetch('http://localhost:3007/fetch-apex-page', {
        method: 'POST', headers: getForgeHeaders(),
        body: JSON.stringify({ appId: parseInt(detectedPage.appId), pageId: parseInt(detectedPage.pageId) }),
        signal: AbortSignal.timeout(70000)
      });
      const data = await res.json();
      if (data.success) {
        pageSql = data.sql;
        apexPageCache[`${detectedPage.appId}.${detectedPage.pageId}`] = { sql: data.sql, mode: data.mode };
        // Preenche campos e textarea automaticamente
        document.getElementById('cfgPageSQL').value = pageSql;
        // Auto-switch para modo incremental quando a pagina citada e o alvo.
        // Em tela nova com referencia/modelo, a pagina importada vira apenas molde.
        if(!isReferenceMode){
          document.getElementById('cfgApp').value   = detectedPage.appId;
          document.getElementById('cfgPage').value  = detectedPage.pageId;
          if (genMode !== 'incr') setGenMode('incr');
        }
        tlog(`✓ Página App=${detectedPage.appId} Page=${detectedPage.pageId} carregada automaticamente (${data.mode})`, 's');
        toast(`Página ${detectedPage.pageId} carregada como contexto`, 's');
      } else {
        tlog(`Página nao encontrada: ${data.error}`, 'w');
      }
    } catch(e) {
      tlog(`Nao foi possivel buscar página: ${e.message}`, 'w');
    }
  }

  // Também inclui o que estiver no cfgPageSQL (importado manualmente)
  if (!pageSql) {
    const manual = document.getElementById('cfgPageSQL')?.value?.trim();
    if (manual) pageSql = manual;
  }

  return { tables: tableResults, pageSql, detectedPage };
}
