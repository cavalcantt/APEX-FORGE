// ── APEX FORGE — AI ──
function getForgeHeaders(extra={}){
  const token = document.getElementById('cfgForgeToken')?.value?.trim();
  const headers = {'Content-Type':'application/json', ...extra};
  if(token) headers['X-Forge-Token'] = token;
  return headers;
}

function parseAIResponse(full){
  const sqlMatch = full.match(/```sql([\s\S]*?)```/i) || full.match(/```([\s\S]*?)```/i);
  if(sqlMatch){
    const sql = sqlMatch[1].trim();
    const text = full.replace(sqlMatch[0],'').trim() || 'SQL gerado seguindo os padrões do app.';
    return {sql, text};
  }
  if(full.toLowerCase().includes('begin\n') || full.toLowerCase().startsWith('begin')){
    return {sql: full.trim(), text: 'SQL gerado! Revise e aplique no APEX.'};
  }
  return {sql: '', text: full};
}

async function sendMsg(){
  const input = document.getElementById('msgInput');
  const msg = input.value.trim();
  if(!msg || isThinking) return;

  addMsg(escHtml(msg), 'user');
  input.value = '';
  input.style.height = 'auto';
  isThinking = true;
  document.getElementById('sendBtn').disabled = true;

  showTyping();
  t0 = Date.now();
  tlog(`Processando: "${msg.slice(0,50)}${msg.length>50?'...':''}"`, 'r');
  prog(10, 'Lendo prompt...');
  applyPromptTargetToConfig(msg);

  const page    = document.getElementById('cfgPage').value.trim();
  const schema  = document.getElementById('cfgSchema').value.trim()||'AGRICOLA';
  const appId   = document.getElementById('cfgApp').value.trim();
  const group   = document.getElementById('cfgGroup').value.trim()||'Processo';
  // Valida obrigatórios
  if(!page){
    hideTyping(); isThinking=false; document.getElementById('sendBtn').disabled=false;
    toast('Preencha o Nº Página no painel direito','e');
    addMsg('⚠ Preencha o <b>Nº Página</b> no painel de configuração antes de gerar.','ai');
    return;
  }
  if(!appId){
    hideTyping(); isThinking=false; document.getElementById('sendBtn').disabled=false;
    toast('Preencha o App ID no painel direito','e');
    addMsg('⚠ Preencha o <b>App ID</b> no painel de configuração antes de gerar.','ai');
    return;
  }

  const guideline = document.getElementById('glText').value;
  const apiKey  = document.getElementById('cfgApiKey')?.value?.trim() || '';
  const ccPort  = document.getElementById('cfgCCPort')?.value?.trim() || '3000';
  const aiMode  = document.getElementById('aiModeSelect')?.value || 'local';
  const fastLocalAi = aiMode === 'claude_local' || aiMode === 'codex_local';
  let sqlResult = '';
  let aiResponse = '';

  tlog(`Modo IA: ${aiMode}`, 'i');

  if(shouldUseLocalIncrementalAgent(msg, aiMode)){
    setGenMode('incr');
    tlog('Agente incremental local assumiu pedido simples para evitar chamada IA lenta.', 'i');
    prog(35, 'Gerando incremento...');
    const gen = generateLocalIncrementalSQL(msg, page, schema, appId);
    if(gen){
      sqlResult = gen.sql;
      aiResponse = gen.response;
      hideTyping();

      const lines = sqlResult ? sqlResult.split('\n').length : 0;
      if(lines > 5) tlog(`SQL incremental gerado: ${lines} linhas`, 's');

      addMsg(aiResponse, 'ai', sqlResult || '');
      prog(100, 'Pronto');
      tlog('Incremento local pronto para aplicar via SQLcl', 's');
      tlog('Aguardando proximo prompt.', 'i');

      isThinking = false;
      document.getElementById('sendBtn').disabled = false;
      return;
    }
  }

  // Caminho rapido: o gerador local e deterministico e nao precisa de
  // contexto remoto, RAG, schema ou timer de IA.
  if(aiMode === 'local'){
    tlog('Usando gerador local (sem IA externa)...', 'w');
    prog(45, 'Gerando localmente...');
    const gen = generateSQL(msg, page, schema, appId, group, {list:'ig',filter:'multi',extras:[]}, []);
    sqlResult = gen.sql;
    aiResponse = gen.response;
    hideTyping();

    const lines = sqlResult ? sqlResult.split('\n').length : 0;
    if(lines > 5) tlog(`SQL gerado: ${lines} linhas`, 's');

    addMsg(aiResponse, 'ai', sqlResult || '', msg);
    prog(100, 'Pronto');
    tlog('SQL gerado localmente', 's');
    tlog('Aguardando proximo prompt.', 'i');

    isThinking = false;
    document.getElementById('sendBtn').disabled = false;
    return;
  }

  prog(15, 'Detectando contexto...');

  // ── AUTO-ENRICH: busca schemas e páginas citados no prompt ──
  prog(20, 'Buscando contexto...');
  const isTurbo = document.getElementById('cfgTurboMode')?.checked;
  if(isTurbo) tlog('🚀 Modo Turbo: busca de tabelas no banco ignorada.', 'w');
  const promptTarget = parseApexTargetFromPrompt(msg);
  const agentNeedsScreenContext =
    !!(promptTarget.page || /\b(?:tela|pagina|page|referencia|modelo|padroes?|igual|parecid[ao]|basead[ao])\b/i.test(msg));
  const needsFullContext = !isTurbo && (!fastLocalAi || genMode === 'incr' || /\b(?:tabela|table|from|join|p[áa]gina|pagina|page)\b/i.test(msg));
  const [enriched, ragCtx] = await Promise.all([
    (needsFullContext || (agentNeedsScreenContext && !isTurbo)) ? autoEnrichContext(msg, schema, appId) : Promise.resolve({ tables: [], pageSql: null, detectedPage: null }),
    fastLocalAi ? Promise.resolve('') : buildRagContext(msg)
  ]);
  if(fastLocalAi && !needsFullContext && !agentNeedsScreenContext) tlog('Claude/Codex em modo rapido: sem auto-enrich/RAG.', 'i');
  if(fastLocalAi && agentNeedsScreenContext) tlog('Claude/Codex agente: contexto da tela/referencia carregado.', 'i');
  prog(30, 'Montando contexto...');

  const systemPrompt = fastLocalAi
    ? buildFastSystemPrompt(guideline, page, schema, appId, group, enriched)
    : buildSystemPrompt(guideline, page, schema, appId, group, enriched, ragCtx);
  if(fastLocalAi) tlog(`Prompt rapido: ${Math.round(systemPrompt.length/1024)}KB`, 'i');
  prog(40, 'IA gerando SQL...');

  let historyText = '';
  if (typeof chatHistory !== 'undefined' && chatHistory.length > 0) {
    historyText = 'CONTEXTO DA CONVERSA (Últimas mensagens):\n' + chatHistory.map(h => 
      (h.role === 'user' ? 'USUÁRIO: ' : 'IA: ') + h.text + 
      (h.sql ? '\n[SQL Gerado Omitido para economizar espaço]' : '')
    ).join('\n\n') + '\n\n---\nNOVO PEDIDO DO USUÁRIO:\n';
  }
  const finalMsg = historyText + msg;

  const _aiT0 = Date.now();
  const _aiTimer = setInterval(() => {
    const s = Math.floor((Date.now() - _aiT0) / 1000);
    prog(40 + Math.min(30, Math.floor(s / 6)), `IA gerando SQL... ${s}s`);
  }, 1000);

  // ── MODO 1: Claude Code via servidor local (Pro, sem custo extra) ──
  if(aiMode === 'claude_local'){
    try {
      tlog('Chamando Claude Code via servidor (porta 3007)...', 'r');
      const res = await fetch('http://localhost:3007/ai-claude', {
        method: 'POST',
        headers: getForgeHeaders(),
        body: JSON.stringify({ system: systemPrompt, message: finalMsg, timeout: 300 }),
        signal: AbortSignal.timeout(320000)
      });
      if(!res.ok) throw new Error('HTTP '+res.status);

      const contentType = res.headers.get('content-type') || '';
      if(contentType.includes('text/event-stream')){
        hideTyping();
        const msgDiv = addMsg('...', 'ai');
        const bubble = msgDiv.querySelector('.msg-bubble');
        
        const reader = res.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let fullText = '';
        
        while(true){
          const {done, value} = await reader.read();
          if(done) break;
          const chunkStr = decoder.decode(value, {stream: true});
          const lines = chunkStr.split('\n');
          for(const line of lines){
            if(line.startsWith('data: ')){
              const data = line.slice(6).trim();
              if(data === '[DONE]') break;
              if(data){
                try {
                  const j = JSON.parse(data);
                  if(j.chunk) fullText += j.chunk;
                } catch(e){}
              }
            }
          }
          bubble.innerHTML = escHtml(fullText).replace(/\n/g, '<br>');
          document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight;
        }
        
        // Final parsing
        const r = parseAIResponse(fullText);
        sqlResult = r.sql; aiResponse = r.text;
        
        // Re-render final message
        msgDiv.remove();
        tlog('Claude Code respondeu ✓', 's');
      } else {
        const data = await res.json();
        if(!data.success) throw new Error(data.error || 'Sem resposta do Claude');
        const r = parseAIResponse(data.text);
        sqlResult = r.sql; aiResponse = r.text;
        tlog('Claude Code respondeu ✓', 's');
      }
    } catch(e){
      clearInterval(_aiTimer);
      tlog(`Erro Claude local: ${e.message}`, 'e');
      hideTyping();
      addMsg(`<b>Erro no Claude Code local:</b> <code>${escHtml(e.message)}</code><br><br>
Verifique:<br>
• Servidor rodando? Execute o <b>start.bat</b><br>
• Claude autenticado? Rode <code>claude</code> no terminal uma vez`, 'ai');
      isThinking=false; document.getElementById('sendBtn').disabled=false;
      prog(0,'Aguardando'); return;
    }

  // ── (mantido para compatibilidade) ────────────────
  } else if(aiMode === 'codex_local'){
    try {
      tlog('Chamando Codex CLI via servidor (porta 3007)...', 'r');
      const res = await fetch('http://localhost:3007/ai-codex', {
        method: 'POST',
        headers: getForgeHeaders(),
        body: JSON.stringify({ system: systemPrompt, message: finalMsg, timeout: 300 }),
        signal: AbortSignal.timeout(320000)
      });
      if(!res.ok) throw new Error('HTTP '+res.status);
      const data = await res.json();
      if(!data.success) throw new Error(data.error || 'Sem resposta do Codex');
      const r = parseAIResponse(data.text);
      sqlResult = r.sql; aiResponse = r.text;
      tlog('Codex CLI respondeu', 's');
    } catch(e){
      clearInterval(_aiTimer);
      tlog(`Erro Codex local: ${e.message}`, 'e');
      hideTyping();
      addMsg(`<b>Erro no Codex CLI local:</b> <code>${escHtml(e.message)}</code><br><br>
Verifique:<br>
• Rode <code>codex --login</code> no terminal<br>
• Se o alias WindowsApps bloquear, instale via <code>npm i -g @openai/codex</code><br>
• Opcional: configure <code>CODEX_CLI_PATH</code> e <code>CODEX_CLI_ARGS</code> no .env`, 'ai');
      isThinking=false; document.getElementById('sendBtn').disabled=false;
      prog(0,'Aguardando'); return;
    }

  // ── MODO 2: API Key Anthropic ──────────────────────
  } else if(aiMode === 'api_key' && apiKey){
    try {
      tlog('Chamando Anthropic API...', 'r');
      const res = await fetch('http://localhost:3007/ai-anthropic', {
        method: 'POST',
        headers: getForgeHeaders(),
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          system: systemPrompt,
          message: finalMsg,
          apiKey: apiKey,
          timeout: 300
        }),
        signal: AbortSignal.timeout(320000)
      });
      const data = await res.json();
      if(!data.success) throw new Error(data.error || 'Sem resposta da Anthropic');
      const full = data.text || '';
      const r = parseAIResponse(full);
      sqlResult = r.sql; aiResponse = r.text;
      tlog('Anthropic API respondeu ✓', 's');
    } catch(e){
      clearInterval(_aiTimer);
      tlog(`API Key erro: ${e.message}`, 'e');
      tlog('Verifique a API Key em Configurações', 'w');
      hideTyping();
      addMsg(`<b>Erro na API Key:</b> <code>${escHtml(e.message)}</code><br>Verifique a chave em ⚙ Configurações.`, 'ai');
      isThinking = false;
      document.getElementById('sendBtn').disabled = false;
      prog(0,'Aguardando');
      return;
    }

  // ── MODO 3: OpenAI / Codex ────────────────────────────
  } else if(aiMode === 'openai'){
    const openAIKey = document.getElementById('cfgOpenAIKey')?.value?.trim() || '';
    const model     = document.getElementById('cfgOpenAIModel')?.value || 'o4-mini';
    if(!openAIKey){
      clearInterval(_aiTimer);
      hideTyping(); isThinking=false; document.getElementById('sendBtn').disabled=false;
      toast('Configure a API Key OpenAI no painel','e');
      addMsg('⚠ Configure a <b>API Key OpenAI</b> no painel de configuração (🟢 OpenAI / Codex).','ai');
      prog(0,'Aguardando'); return;
    }
    try {
      tlog(`Chamando OpenAI API (${model})...`, 'r');
      const res = await fetch('http://localhost:3007/ai-openai', {
        method: 'POST',
        headers: getForgeHeaders(),
        body: JSON.stringify({
          system: systemPrompt,
          message: finalMsg,
          model: model,
          apiKey: openAIKey,
          timeout: 300
        }),
        signal: AbortSignal.timeout(320000)
      });
      const data = await res.json();
      if(!data.success) throw new Error(data.error || 'Sem resposta da OpenAI');
      const full = data.text || '';
      const r = parseAIResponse(full);
      sqlResult = r.sql; aiResponse = r.text;
      tlog(`OpenAI (${model}) respondeu ✓`, 's');
    } catch(e){
      clearInterval(_aiTimer);
      tlog(`OpenAI erro: ${e.message}`, 'e');
      hideTyping();
      addMsg(`<b>Erro na OpenAI API:</b> <code>${escHtml(e.message)}</code><br>Verifique a API Key em Configurações.`, 'ai');
      isThinking=false; document.getElementById('sendBtn').disabled=false;
      prog(0,'Aguardando'); return;
    }

  // ── MODO 4: Gerador local (sem IA externa) ─────────
  } else {
    tlog('Usando gerador local (sem IA externa)...', 'w');
    const gen = generateSQL(msg, page, schema, appId, group, {list:'ig',filter:'multi',extras:[]}, []);
    sqlResult = gen.sql;
    aiResponse = gen.response;
    tlog('SQL gerado localmente ✓', 's');
  }

  clearInterval(_aiTimer);
  prog(75, 'SQL pronto...');
  hideTyping();

  const lines = sqlResult ? sqlResult.split('\n').length : 0;
  if(lines > 5) tlog(`SQL gerado: ${lines} linhas`, 's');

  addMsg(aiResponse, 'ai', sqlResult || '', msg);
  prog(100, 'Pronto ✓');
  tlog('Aguardando próximo prompt.', 'i');

  isThinking = false;
  document.getElementById('sendBtn').disabled = false;
}

function onAiModeChange(){
  const mode = document.getElementById('aiModeSelect').value;
  document.getElementById('ccConfig').style.display     = mode==='claude_local' ? 'block' : 'none';
  document.getElementById('codexConfig').style.display  = mode==='codex_local'  ? 'block' : 'none';
  document.getElementById('apiKeyConfig').style.display = mode==='api_key'      ? 'block' : 'none';
  document.getElementById('openaiConfig').style.display = mode==='openai'       ? 'block' : 'none';
  const labels = {claude_local:'⚡ Claude Code (Pro)', api_key:'🔷 Anthropic', openai:'🟢 OpenAI/Codex', local:'📦 Local'};
  tlog(`Modo IA: ${labels[mode] || mode}`, 'i');
}

async function testClaudeLocal(){
  const status = document.getElementById('ccStatus');
  status.textContent = '⏳ Testando...';
  status.style.color = 'var(--ylw)';
  try {
    const res = await fetch('http://localhost:3007/health', {signal: AbortSignal.timeout(3000)});
    if(res.ok){
      status.textContent = '✓ Servidor ativo — Claude Code pronto';
      status.style.color = 'var(--grn)';
      tlog('Servidor local ativo — Claude Code disponível ✓','s');
      toast('Servidor pronto!','s');
    } else { throw new Error('HTTP '+res.status); }
  } catch(e){
    status.textContent = '✗ Servidor offline — rode o start.bat primeiro';
    status.style.color = 'var(--red)';
    tlog('Servidor offline: '+e.message,'e');
  }
}

async function testCodexLocal(){
  const status = document.getElementById('codexStatus');
  status.textContent = 'Testando...';
  status.style.color = 'var(--ylw)';
  try {
    const res = await fetch('http://localhost:3007/codex-health', {signal: AbortSignal.timeout(3000)});
    const data = await res.json();
    if(res.ok && data.success){
      status.textContent = 'Codex encontrado: ' + (data.path || 'PATH');
      status.style.color = 'var(--grn)';
      tlog('Codex CLI encontrado. Args: ' + (data.args || 'padrao'), 's');
      toast('Codex CLI encontrado!','s');
    } else {
      throw new Error(data.error || 'codex nao encontrado');
    }
  } catch(e){
    status.textContent = 'Codex indisponivel - rode codex --login ou ajuste CODEX_CLI_PATH';
    status.style.color = 'var(--red)';
    tlog('Codex CLI indisponivel: ' + e.message, 'e');
  }
}
