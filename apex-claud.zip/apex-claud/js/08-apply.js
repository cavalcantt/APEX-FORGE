// ── APEX FORGE — Apply ──

// Detecta se é SQL no formato de exportação APEX ou PL/SQL direto
function detectSQLType(sql) {
  const s = (sql || '').trim().toLowerCase();
  if (s.includes('wwv_flow_imp.import_begin')) return 'apex_export';
  if (/^\s*(declare|begin)\b/m.test(s)) return 'plsql';
  if (/^\s*(create|insert|update|delete|alter)\b/im.test(s)) return 'dml';
  return 'unknown';
}

function validateApexImportSQL(sql){
  const issues = [];
  const warnings = [];
  const s = (sql || '').trim();
  const type = detectSQLType(s);

  // Apenas valida formato de export APEX quando realmente for um export
  if (type === 'apex_export') {
    if(!/wwv_flow_imp\.import_begin\s*\(/i.test(s)) issues.push('SQL nao contem wwv_flow_imp.import_begin.');
    if(!/wwv_flow_imp\.import_end\s*\(/i.test(s)) issues.push('SQL nao contem wwv_flow_imp.import_end.');
    if(!/wwv_flow_imp_page\.remove_page\s*\(/i.test(s)) warnings.push('SQL nao remove a pagina antes de criar. Verifique se isso e intencional.');
    if(!/\bcommit\s*;/i.test(s)) warnings.push('SQL nao contem commit explicito.');
    if(!/p_protection_level\s*=>\s*'C'/i.test(s)) warnings.push("p_protection_level=>'C' nao encontrado.");
    if(!/p_autocomplete_on_off\s*=>\s*'OFF'/i.test(s)) warnings.push("p_autocomplete_on_off=>'OFF' nao encontrado.");
  }
  // PL/SQL direto: apenas verifica comandos perigosos
  // (DECLARE/BEGIN gerado pelo Codex/Claude é válido e não precisa do wrapper de export)

  // Comandos destrutivos - bloqueados em qualquer tipo
  [
    /\bdrop\s+(table|user|schema|database)\b/i,
    /\btruncate\s+table\b/i,
    /\bdelete\s+from\s+(?!wwv_flow|apex_)/i,
    /\bupdate\s+(?!wwv_flow|apex_)/i,
    /\bexecute\s+immediate\b/i
  ].forEach(rx => {
    const m = s.match(rx);
    if(m) issues.push('Comando potencialmente perigoso detectado: ' + m[0]);
  });

  return {valid: issues.length === 0, issues, warnings, type};
}

async function validateSQLBeforeRun(sql){
  const local = validateApexImportSQL(sql);
  try {
    const res = await fetch('http://localhost:3007/validate-sql', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({sql}),
      signal: AbortSignal.timeout(5000)
    });
    if(res.ok){
      const data = await res.json();
      // Usa validação server-side apenas se for export APEX (tem import_begin)
      if(data.validation && local.type === 'apex_export') return data.validation;
    }
  } catch(e){
    tlog('Validacao server-side indisponivel; usando validacao local.', 'w');
  }
  return local;
}


function renderValidation(validation){
  const parts = [];
  if(validation.issues?.length){
    parts.push('<b>Bloqueios:</b><br>' + validation.issues.map(x => '• ' + escHtml(x)).join('<br>'));
  }
  if(validation.warnings?.length){
    parts.push('<b>Avisos:</b><br>' + validation.warnings.map(x => '• ' + escHtml(x)).join('<br>'));
  }
  return parts.join('<br><br>');
}

function resetAplicandoSQL(){
  _aplicando = false;
  document.querySelectorAll('.apply-btn').forEach(b=>{b.disabled=false;b.style.opacity='';});
}

async function aplicarSQL(){
  if(_aplicando){toast('Aguarde, já está aplicando...','w');return;}
  if(!lastSQL){toast('Nenhum SQL para aplicar','w');return;}
  _aplicando = true;
  document.querySelectorAll('.apply-btn').forEach(b=>{b.disabled=true;b.style.opacity='0.5';});

  const pg    = document.getElementById('cfgPage').value || '?';
  const appId = document.getElementById('cfgApp')?.value || conn?.app || '255';
  const lines = lastSQL.split('\n').length;

  const validation = await validateSQLBeforeRun(lastSQL);
  if(!validation.valid){
    tlog('Validacao bloqueou a aplicacao do SQL.', 'e');
    toast('SQL bloqueado pela validacao','e');
    addMsg(`<b>SQL bloqueado pela validacao.</b><br><br>${renderValidation(validation)}`, 'ai');
    resetAplicandoSQL();
    return;
  }
  if(validation.warnings?.length){
    tlog(`Validacao com ${validation.warnings.length} aviso(s).`, 'w');
    const ok = confirm('A validacao encontrou avisos:\n\n' + validation.warnings.join('\n') + '\n\nDeseja aplicar mesmo assim?');
    if(!ok){
      toast('Aplicacao cancelada','w');
      resetAplicandoSQL();
      return;
    }
  }

  // Detecta tipo: só faz validação APEX no servidor para exports (com import_begin)
  const sqlType = detectSQLType(lastSQL);
  const doServerValidate = sqlType === 'apex_export';
  tlog(`Enviando ${lines} linhas para o SQLcl local (tipo: ${sqlType})...`,'r');
  prog(30,'Executando via SQLcl...');

  try {
    const res = await fetch('http://localhost:3007/execute-sqlcl', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({
        sql: lastSQL,
        validateApex: doServerValidate
      }),
      signal: AbortSignal.timeout(600000)
    });

    tlog(`HTTP ${res.status} recebido do servidor SQLcl`,'i');
    prog(70,'Processando resposta...');

    let data = null;
    try { data = await res.json(); } catch(_) {}

    if(!res.ok){
      throw new Error(data?.error || `HTTP ${res.status}`);
    }

    if(data?.success){
      prog(100,'Aplicado via SQLcl');
      tlog(`SQLcl concluiu em ${data.duration || '?'}s`,'s');
      toast(`Pagina ${pg} aplicada via SQLcl!`,'s');
      ragStoreSucess(lastSQL, pg, appId, ['success', 'pagina-' + pg]);

      const outPreview = data.output
        ? `<br><br><b>SQLcl:</b><br><code>${escHtml(data.output.slice(-1200))}</code>`
        : '';
      const designerUrl = conn?.url
        ? `<br><br><a href="${conn.url.replace(/\/+$/,'')}/r/apex/app-builder/page-designer?app=${appId}&page=${pg}" target="_blank">Abrir no Page Designer</a>`
        : '';

      addMsg(`Pagina <b>${pg}</b> aplicada via <b>SQLcl</b>.${designerUrl}${outPreview}`,'ai');
      return;
    }

    const errMsg = data?.error || 'Falha na execucao via SQLcl';
    tlog(`Erro SQLcl: ${errMsg}`,'e');
    if(data?.output) tlog(data.output.slice(-600),'e');
    toast('Erro no SQLcl - veja o log','e');
    prog(0,'Erro SQLcl');
    addMsg(`Erro ao aplicar via SQLcl:<br><code>${escHtml(errMsg)}</code>${
      data?.output ? `<br><br><b>Output:</b><br><code>${escHtml(data.output.slice(-1600))}</code>` : ''
    }`,'ai');

  } catch(e){
    if(e.name === 'AbortError'){
      tlog('Timeout 600s - SQL muito grande, banco lento ou SQLcl travado','e');
      toast('Timeout no SQLcl','e');
      prog(0,'Timeout');
    } else {
      tlog(`Erro ao chamar SQLcl local: ${e.message}`,'e');
      tlog('Verifique se o start.bat esta rodando e se SQLCL_PATH/DB_CONNECTION estao corretos no .env','w');
      toast('Erro ao chamar SQLcl','e');
      prog(0,'Erro');
      addMsg(`Erro ao chamar o SQLcl local:<br><code>${escHtml(e.message)}</code><br><br>
Verifique:<br>
- Servidor local rodando com <code>start.bat</code><br>
- <code>SQLCL_PATH</code> no <code>.env</code><br>
- <code>DB_CONNECTION</code> no <code>.env</code>`,'ai');
    }
  } finally {
    resetAplicandoSQL();
  }
}

function copiarSQL(){
  if(!lastSQL){toast('Nenhum SQL','w');return;}
  navigator.clipboard.writeText(lastSQL).then(()=>toast('SQL copiado!','s'));
}
