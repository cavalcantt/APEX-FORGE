// ── APEX FORGE — State ──
let conn = null;
let t0 = Date.now();
let isThinking = false;
let lastSQL = '';
let _aplicando = false;
let serverUp = false;

let schCurrentOwner = '';
let schCurrentTable = '';
let schCurrentType  = '';
let schAllTables    = [];
let schColumns      = [];
let schSource       = '';
let schTablesCache  = {};
let schColumnsCache = {};
let apexPageCache   = {};

let genMode = 'nova';
