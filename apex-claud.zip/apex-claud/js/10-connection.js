// ── APEX FORGE — Connection ──
function openModal(){
  document.getElementById('modalBack').classList.add('open');
}
function closeModal(){document.getElementById('modalBack').classList.remove('open');}

async function conectar(){
  const url     = document.getElementById('mUrl').value.trim().replace(/\/+$/, '');
  const appId   = document.getElementById('mApp').value.trim();
  const dbSchema= document.getElementById('mWs')?.value.trim() || 'AGRICOLA';
  const session = document.getElementById('mSession')?.value.trim() || '';

  if(!url)    { toast('Informe a URL do APEX','e'); return; }
  if(!session){ toast('Informe a Sessão APEX (da URL do browser)','e'); return; }
  if(!appId)  { toast('Informe o App ID','e'); return; }

  tlog(`Testando wwv_flow.ajax em: ${url}`,'r');
  prog(30,'Testando conexão APEX...');

  // Testa com um PL/SQL nulo — se a sessão for válida responde ok
  const apexUrl  = url + '/wwv_flow.ajax';
  const testForm = new URLSearchParams();
  testForm.append('p_flow_id',      appId);
  testForm.append('p_flow_step_id', '0');
  testForm.append('p_instance',     session);
  testForm.append('p_request',      'APPLICATION_PROCESS=FORGE_EXECUTE');
  testForm.append('p_arg_names',    'P0_FORGE_SQL');
  testForm.append('p_arg_values',   'BEGIN NULL; END;');

  let testOk = false;
  try {
    const res = await fetch(apexUrl, {
      method:      'POST',
      headers:     {'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},
      credentials: 'include',
      body:        testForm.toString(),
      signal:      AbortSignal.timeout(8000)
    });
    const body = await res.text().catch(()=>'');
    tlog(`Ping HTTP ${res.status} — ${body.slice(0,80)}`,'i');
    // 200 com qualquer body (OK ou erro Oracle) = APEX respondeu = conexão ok
    if(res.status === 200){ testOk = true; }
    else if(res.status === 404){ tlog('wwv_flow.ajax não encontrado — verifique a URL base do APEX','e'); }
    else if(res.status === 401 || res.status === 403){ tlog(`HTTP ${res.status} — sessão inválida ou expirada`,'e'); }
    else { tlog(`HTTP ${res.status} inesperado`,'w'); testOk = true; }
  } catch(e){
    if(e.name === 'AbortError'){
      tlog('Timeout 8s — verifique a URL','e');
      toast('Timeout — verifique a URL do APEX','e');
      prog(0,'Timeout'); return;
    }
    // Qualquer outro erro de rede = URL errada
    tlog(`Erro de rede: ${e.message}`,'e');
    toast('URL inacessível — verifique a URL do APEX','e');
    prog(0,'Sem conexão'); return;
  }

  // Salva conexão independente do resultado do ping
  // (o processo FORGE_EXECUTE pode não existir ainda — conectamos assim amesmo)
  conn = { url, app: appId, dbSchema, session };
  document.getElementById('cfgApp').value   = appId;
  document.getElementById('cfgSchema').value = dbSchema;
  document.getElementById('cdot').className  = 'cdot on';

  const host = url.replace('https://','').replace('http://','').split('/')[0];

  if(testOk){
    document.getElementById('connLabel').textContent = '✓ ' + host;
    prog(100,'Conectado ✓');
    tlog('APEX respondeu — conexão OK ✓','s');
    toast('Conectado ao APEX!','s');
    addMsg(`✓ <b>Conectado!</b> APEX em <code>${url}</code><br><br>
Agora gere um SQL e clique <b>Aplicar</b>.<br><br>
⚠ Certifique-se que o processo <b>FORGE_EXECUTE</b> existe na <b>Página 0</b> do App <b>${appId}</b>.`,'ai');
  } else {
    document.getElementById('connLabel').textContent = '⚠ ' + host;
    prog(80,'Conectado (verifique sessão)');
    tlog('APEX alcançado mas sessão pode estar inválida — verifique','w');
    toast('URL ok — verifique a sessão APEX','w');
    addMsg(`⚠ URL <code>${url}</code> acessível, mas o APEX retornou erro.<br><br>
Possíveis causas:<br>
• <b>Sessão expirada</b> — abra o APEX no browser, copie o número da URL (<code>?session=XXXXX</code>) e reconecte<br>
• <b>App ID errado</b> — confirme que é <b>${appId}</b><br>
• <b>FORGE_EXECUTE não existe</b> na Página 0`,'ai');
  }
  closeModal();
}
