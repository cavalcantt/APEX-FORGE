// ── APEX FORGE — SQLcl Runner ──
function sqlclCarregarArquivo(input){
  const file = input.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('sqlclEditor').value = e.target.result;
    document.getElementById('sqlclFileName').textContent = '📄 ' + file.name;
    sqlclUpdateLineCount();
    sqlclLog(`Arquivo carregado: ${file.name} (${(file.size/1024).toFixed(1)} KB)`, 's');
  };
  reader.readAsText(file);
}

function sqlclUpdateLineCount(){
  const val = document.getElementById('sqlclEditor').value;
  const lines = val.split('\n').length;
  document.getElementById('sqlclLineCount').textContent = lines + ' linhas';
}

function sqlclLimpar(){
  document.getElementById('sqlclEditor').value = '';
  document.getElementById('sqlclFileName').textContent = '';
  document.getElementById('sqlclLineCount').textContent = '';
  document.getElementById('sqlclLog').innerHTML = '';
  setSqlclProg(0,'Aguardando');
  document.getElementById('sqlclStatus').textContent = 'IDLE';
}

function sqlclLog(msg, type='i'){
  const el = document.getElementById('sqlclLog');
  const d  = document.createElement('div');
  const icons = {i:'·',s:'✓',e:'✗',w:'⚠',r:'▶'};
  const colors = {i:'var(--t2)',s:'var(--grn)',e:'var(--red)',w:'var(--ylw)',r:'var(--acc3)'};
  d.style.cssText = `display:flex;gap:8px;margin-bottom:2px;animation:fadeup .2s ease;`;
  d.innerHTML = `<span style="color:${colors[type]||'var(--t2)'};flex-shrink:0">${icons[type]||'·'}</span><span style="color:var(--t2)">${msg}</span>`;
  el.appendChild(d);
  el.scrollTop = el.scrollHeight;
}

function setSqlclProg(pct, label){
  document.getElementById('sqlclProg').style.width = pct+'%';
  document.getElementById('sqlclProgPct').textContent = pct+'%';
  document.getElementById('sqlclProgLabel').textContent = label;
}

function resetSqlclExecuteButton(){
  const btn = document.getElementById('btnSqlclExecutar');
  btn.disabled = false;
  btn.textContent = 'Executar via SQLcl';
}

async function sqlclExecutar(){
  const sql = document.getElementById('sqlclEditor').value.trim();
  if(!sql){ toast('Cole o SQL primeiro','w'); return; }

  const btn = document.getElementById('btnSqlclExecutar');
  btn.disabled = true;
  btn.textContent = '⏳ Executando via SQLcl...';
  document.getElementById('sqlclStatus').textContent = 'RUNNING';
  document.getElementById('sqlclStatus').style.color = 'var(--ylw)';

  const lines = sql.split('\n').length;
  sqlclLog(`Executando ${lines} linhas via SQLcl`, 'r');
  setSqlclProg(20, 'Preparando...');

  try {
    const shouldValidateApex = /wwv_flow_imp|wwv_flow_imp_page/i.test(sql);
    if(shouldValidateApex){
      const validation = await validateSQLBeforeRun(sql);
      if(!validation.valid){
        sqlclLog('SQL bloqueado pela validacao:', 'e');
        validation.issues.forEach(i => sqlclLog(i, 'e'));
        toast('SQL bloqueado pela validacao','e');
        setSqlclProg(0,'Bloqueado');
        resetSqlclExecuteButton();
        return;
      }
      if(validation.warnings?.length){
        validation.warnings.forEach(w => sqlclLog('Aviso: ' + w, 'w'));
        const ok = confirm('A validacao encontrou avisos:\n\n' + validation.warnings.join('\n') + '\n\nDeseja executar mesmo assim?');
        if(!ok){
          sqlclLog('Execucao cancelada pelo usuario.', 'w');
          setSqlclProg(0,'Cancelado');
          resetSqlclExecuteButton();
          return;
        }
      }
    }

    sqlclLog('Chamando executor SQLcl via servidor...', 'i');
    setSqlclProg(50, 'Executando SQLcl...');

    sqlclLog('Aguardando resposta do servidor (timeout: 300s)...', 'i');
    const response = await fetch('http://localhost:3007/execute-sqlcl', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({
        sql: sql,
        validateApex: shouldValidateApex
      }),
      signal: AbortSignal.timeout(600000)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    setSqlclProg(100, 'Concluído');

    if (result.success) {
      sqlclLog('SQL executado com sucesso via SQLcl ✓', 's');
      document.getElementById('sqlclStatus').textContent = 'DONE';
      document.getElementById('sqlclStatus').style.color = 'var(--grn)';
      toast('SQL executado via SQLcl!','s');

      // Mostrar output do SQLcl
      if (result.output) {
        sqlclLog('Output do SQLcl:', 'i');
        result.output.split('\n').forEach(line => {
          if (line.trim()) sqlclLog(line, 'i');
        });
      }
    } else {
      const errMsg = result.error || 'Falha na execução (sem detalhes)';
      sqlclLog(`Erro: ${errMsg}`, 'e');
      if (result.output) {
        sqlclLog('Output do SQLcl:', 'w');
        result.output.split('\n').forEach(line => { if (line.trim()) sqlclLog(line, 'e'); });
      }
      document.getElementById('sqlclStatus').textContent = 'ERROR';
      document.getElementById('sqlclStatus').style.color = 'var(--red)';
      toast('Erro na execução SQLcl','e');
      setSqlclProg(0,'Erro');
    }

  } catch(e) {
    if (e.message.includes('fetch')) {
      // Servidor não está rodando - mostrar instruções
      sqlclLog('Servidor local não encontrado', 'e');
      sqlclLog('Para usar o SQLcl Runner:', 'w');
      sqlclLog('1. Abra PowerShell no diretório Forge', 'i');
      sqlclLog('2. Execute: .\\start.bat', 'i');
      sqlclLog('3. Ou copie o SQL e execute manualmente no SQLcl', 'i');
      document.getElementById('sqlclStatus').textContent = 'NO_SERVER';
      document.getElementById('sqlclStatus').style.color = 'var(--red)';
      toast('Servidor local não disponível - veja instruções no log','w');
      setSqlclProg(0,'Servidor offline');
    } else {
      sqlclLog(`Erro: ${e.message}`, 'e');
      document.getElementById('sqlclStatus').textContent = 'ERROR';
      document.getElementById('sqlclStatus').style.color = 'var(--red)';
      toast('Erro na execução','e');
      setSqlclProg(0,'Erro');
    }
  }

  btn.disabled = false;
  btn.innerHTML = '🔧 Executar via SQLcl';
}
