// ── APEX FORGE — Generator ──
function generateIncrementalSQL(msg, p, schema, appId, tmpl) {
  const pageSql = (document.getElementById('cfgPageSQL')?.value || '');
  
  function findRegionId(regionName) {
    if (!regionName || !pageSql) return `wwv_flow_imp.id(${p}01)`;
    const safeRegex = regionName.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const match = pageSql.match(new RegExp(`p_id=>wwv_flow_imp\\.id\\((\\d+)\\)[\\s\\S]*?p_plug_name=>'[^']*${safeRegex}[^']*'`, 'i'));
    if (match) return `wwv_flow_imp.id(${match[1]})`;
    return `wwv_flow_imp.id(${p}01)`;
  }

  let sql = '';
  let response = '';

  const btnMatch = msg.match(/adicion[ea] .*bot[aã]o\s+(?:chamado\s+)?["']?([^"'\s]+)["']?(?:\s+na\s+regi[aã]o\s+["']?([^"'\n]+)["']?)?/i);
  const itemMatch = msg.match(/adicion[ea] .*item\s+(?:chamado\s+)?["']?([^"'\s]+)["']?(?:\s+na\s+regi[aã]o\s+["']?([^"'\n]+)["']?)?/i);
  const procMatch = msg.match(/adicion[ea] .*processo\s+(?:chamado\s+)?["']?([^"'\n]+)["']?/i);
  const regMatch = msg.match(/adicion[ea] .*regi[aã]o\s+(?:chamad[ao]\s+)?["']?([^"'\n]+)["']?/i);

  let genId = Math.floor(Math.random() * 90) + 10;

  if (btnMatch) {
    const btnName = btnMatch[1].toUpperCase();
    const regionName = btnMatch[2];
    const parentId = findRegionId(regionName);
    sql = `wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(${p}${genId})
,p_button_sequence=>10
,p_button_plug_id=>${parentId}
,p_button_name=>'${btnName}'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(${tmpl.btn_no_icon})
,p_button_is_hot=>'N'
,p_button_image_alt=>'${btnName}'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);`;
    response = `Botão <b>${btnName}</b> adicionado${regionName ? ' na região ' + regionName : ''}.`;

  } else if (itemMatch) {
    const itemName = itemMatch[1].toUpperCase();
    const regionName = itemMatch[2];
    const parentId = findRegionId(regionName);
    sql = `wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(${p}${genId})
,p_name=>'${itemName.startsWith('P') ? itemName : `P${p}_${itemName}`}'
,p_item_sequence=>10
,p_item_plug_id=>${parentId}
,p_prompt=>'${itemName}'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(${tmpl.field_template})
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);`;
    response = `Item <b>${itemName}</b> adicionado${regionName ? ' na região ' + regionName : ''}.`;

  } else if (procMatch) {
    const procName = procMatch[1];
    sql = `wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(${p}${genId})
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'${procName}'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'
))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);`;
    response = `Processo <b>${procName}</b> adicionado.`;

  } else if (regMatch) {
    const regName = regMatch[1];
    sql = `wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}${genId})
,p_plug_name=>'${regName}'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_html})
,p_plug_display_sequence=>10
,p_location=>null
);`;
    response = `Região <b>${regName}</b> adicionada.`;

  } else {
    response = `Comando não reconhecido. Use: "Adiciona botão X na região Y", "Adiciona item X", "Adiciona região X" ou "Adiciona processo X".`;
    sql = `-- Comando não reconhecido pelo gerador local incremental`;
  }

  const finalSql = `begin
wwv_flow_imp.import_begin(
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.16'
,p_default_workspace_id=>${getWorkspaceId(appId)}
,p_default_application_id=>${appId}
,p_default_id_offset=>0
,p_default_owner=>'${schema}'
);

${sql}

wwv_flow_imp.import_end(
  p_auto_install_sup_obj=>nvl(wwv_flow_application_install.get_auto_install_sup_obj,false)
);
commit;
end;`;

  return { sql: finalSql, response };
}

function generateSQL(msg, page, schema, appId, group, opts, skills){
  const hasAbas = opts.extras.includes('abas');
  const tmpl    = getTemplates(appId);
  const hasRO   = skills.includes('readonly') && tmpl.readonly_fn !== false;
  const hasSetCustom = tmpl.setcustomconfig !== false;
  const useLovCascade = tmpl.lov_cascade === true;
  const p = page;

  if (typeof genMode !== 'undefined' && genMode === 'incr') {
    return generateIncrementalSQL(msg, p, schema, appId, tmpl);
  }

  // ── 1. NOME DA TELA ──────────────────────────────────
  // Prioridade: "chamada X", "tela de X", "página N — X", senão "Nova Tela"
  const nameMatch = msg.match(/chamada\s+[""']?([^"'\n,\.]{3,40})/i)
                 || msg.match(/p[áa]gina\s+\d+\s+(?:—|-)\s*([^\n,\.]{3,40})/i)
                 || msg.match(/tela\s+(?:de\s+)?[""']?([A-ZÀ-Úa-zà-ú][^\n"',\.]{2,30})/i);
  const pageName = nameMatch ? nameMatch[1].trim().replace(/['"]/g,'').replace(/\s+com\s+.*/i,'').trim() : 'Nova Tela';
  const alias    = pageName.toLowerCase().normalize('NFD')
    .replace(/[̀-ͯ]/g,'').replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,'');

  // ── 2. QUERIES DOS FILTROS ────────────────────────────
  // Pega TODOS os blocos sql do prompt em ordem
  const allSqlBlocks = [...msg.matchAll(/```sql\s*([\s\S]*?)```/gi)].map(m=>m[1].trim());

  // Encontra índice do bloco do IG (marcado por "selecte da" ou contem FROM+talhao sem ser filtro)
  const igMarkerPos = msg.search(/selecte?\s+da\s+i(teractive|g)/i);

  // Pega texto antes do marcador do IG para encontrar filtros
  const msgBeforeIG = igMarkerPos > -1 ? msg.slice(0, igMarkerPos) : msg;
  const filterSqlBlocks = [...msgBeforeIG.matchAll(/```sql\s*([\s\S]*?)```/gi)].map(m=>m[1].trim());

  const filterBlocks = filterSqlBlocks.length > 0
    ? filterSqlBlocks
    : allSqlBlocks.slice(0, -1); // todos menos o último (que é o IG)

  // ── 3. QUERY DO IG ───────────────────────────────────
  let igQuery = '';
  // Tenta pegar após marcador
  const igMarker = msg.search(/selecte?\s+da\s+i(teractive|g)/i);
  if(igMarker > -1){
    const afterMarker = msg.slice(igMarker);
    const inBlock = afterMarker.match(/```sql\s*([\s\S]*?)```/i);
    if(inBlock){
      igQuery = inBlock[1].trim();
    } else {
      const rawSelect = afterMarker.match(/SELECT[\s\S]+/i);
      if(rawSelect){
        igQuery = rawSelect[0].split('\n').filter(l =>
          l.trim().match(/^(SELECT|FROM|WHERE|AND|OR|JOIN|,|\(|\))/i) || l.trim()===''
        ).join('\n').trim();
      }
    }
  }
  // Fallback: último bloco ```sql```
  if(!igQuery){
    const allBlocks2 = [...msg.matchAll(/```sql\s*([\s\S]*?)```/gi)].map(m=>m[1].trim());
    igQuery = allBlocks2.sort((a,b)=>b.length-a.length)[0]
           || `SELECT id, descricao FROM ${schema}.entidade WHERE 1=1`;
  }
  igQuery = igQuery.replace(/```sql|```/g,'').trim();

  // ── 4. NOMES DOS ITENS DE FILTRO ─────────────────────
  // Pega itens explícitos do prompt (P81_FAZENDA etc)
  const explicitItems = [...new Set(
    [...msg.matchAll(/\bP\d+_[A-Z][A-Z0-9_]+/g)].map(m=>m[0])
    .filter(i => !i.includes('COLUMN') && !i.includes('RADIO') && !i.includes('TABINDEX'))
  )];

  let filterItems = [];
  if(explicitItems.length > 0){
    // Usa os itens explícitos encontrados no prompt
    // Prioriza itens que aparecem nos filtros (não na query do IG)
    const msgSemIG = msg.slice(0, igMarker > -1 ? igMarker : msg.length);
    const itemsNaDescricao = [...new Set(
      [...msgSemIG.matchAll(/\bP\d+_[A-Z][A-Z0-9_]+/g)].map(m=>m[0])
      .filter(i => !i.includes('COLUMN') && !i.includes('RADIO') && !i.includes('TABINDEX'))
    )];
    filterItems = itemsNaDescricao.length > 0 ? itemsNaDescricao : explicitItems.slice(0,6);
  } else {
    // Gera baseado em quantos filtros foram pedidos
    const numFilters = parseInt(msg.match(/(\d+)\s+(?:filtros?|lov)/i)?.[1] || '1');
    const names = ['FAZENDA','ZONA','SAFRA','PLANEJAMENTO','TALHAO','OPERACAO'];
    filterItems = Array.from({length: Math.min(numFilters,6)}, (_,i) =>
      `P${p}_${names[i]||'FILTRO'+(i+1)}`
    );
  }

  // ── 5. MAPEIA QUERY → ITEM (para LOV cascata) ────────
  // Para cada item de filtro, tenta encontrar a query correspondente
  const filterQueries = {};
  filterItems.forEach((item, i) => {
    filterQueries[item] = filterBlocks[i] || null;
  });

  // ── 6. DETECTA ITEM PAI (cascata) ────────────────────
  // Item com "cascata de P8X_XXX" ou "where xxx = :P8X_XXX" na query
  const cascadeMap = {};
  filterItems.forEach(item => {
    const q = filterQueries[item] || '';
    const parentMatch = q.match(/:P\d+_([A-Z_]+)/);
    if(parentMatch){
      const parentItem = filterItems.find(fi => fi.endsWith('_'+parentMatch[1]));
      if(parentItem) cascadeMap[item] = parentItem;
    }
    // Também verifica no texto do prompt
    const textMatch = msg.match(new RegExp(`${item.replace(/\d/g,'\\d')}[^\\n]*cascata[^\\n]*?(P\\d+_[A-Z_]+)`, 'i'));
    if(textMatch && !cascadeMap[item]) cascadeMap[item] = textMatch[1];
  });

  // ── 7. GERA SQL DOS ITENS ────────────────────────────
  function itemSQL(item, i){
    const q = filterQueries[item];
    const cascade = cascadeMap[item];
    const isFirst = i === 0;
    const label = item.replace(/P\d+_/,'').replace(/_/g,' ')
      .toLowerCase().replace(/\b\w/g,c=>c.toUpperCase());

    const lovSQL = q ? q : `select cod||' - '||descricao d, cod r from ${schema}.tabela order by 1`;

    return `-- ${item}
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(${p}${10+i})
,p_name=>'${item}'
,p_item_sequence=>${(i+1)*10}
,p_item_plug_id=>wwv_flow_imp.id(${p}01)
,p_prompt=>'${label}'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
${lovSQL.split('\n').map(l=>`'${l.replace(/'/g,"''")}',`).join('\n')}
''))
${cascade ? `,p_lov_cascade_parent_items=>'${cascade}'\n,p_ajax_optimize_refresh=>'Y'` : ''}
,p_cSize=>30
${!isFirst ? ",p_begin_on_new_line=>'N'" : ''}
,p_field_template=>wwv_flow_imp.id(${tmpl.field_template})
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);`;
  }

  // ── 8. MONTA SQL COMPLETO ────────────────────────────
  const sql = `begin
wwv_flow_imp.import_begin(
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.16'
,p_default_workspace_id=>${getWorkspaceId(appId)}
,p_default_application_id=>${appId}
,p_default_id_offset=>0
,p_default_owner=>'${schema}'
);

wwv_flow_imp_page.remove_page(p_flow_id=>wwv_flow.g_flow_id,p_page_id=>${p});

wwv_flow_imp_page.create_page(
 p_id=>${p}
,p_name=>'${pageName}'
,p_alias=>'${alias.toUpperCase()}'
,p_step_title=>'${pageName}'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'${hasRO ? `
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>'csweb.pkg_apex_scaffold.fn_page_is_readonly'
,p_read_only_when2=>'PLSQL'` : ''}
,p_help_text=>'cod_telas:0;page_version: 1;'
,p_page_component_map=>'21'
);
-- ─── FILTROS ──────────────────────────────────────────
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}01)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_html})
,p_plug_display_sequence=>10009
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
);
${filterItems.map((item, i) => itemSQL(item, i)).join('\n')}
-- Botão FILTRAR
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(${p}20)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(${p}01)
,p_button_name=>'FILTRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(${tmpl.btn_no_icon})
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filtrar'
,p_grid_column_css_classes=>'cs-flex-end'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
${hasAbas ? `-- ─── ABAS ──────────────────────────────────────────────
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}02)
,p_plug_name=>'Controle de abas'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_html})
,p_plug_display_sequence=>10029
,p_location=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(${p}21)
,p_name=>'P${p}_TABINDEX'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(${p}02)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(${p}22)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(${p}02)
,p_button_name=>'BTN_LISTAGEM'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(${tmpl.btn_no_icon})
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Listagem'
,p_button_position=>'PREVIOUS'
,p_button_css_classes=>'cs-Button--tabs'
);` : ''}
-- ─── BODY-LISTAGEM ────────────────────────────────────
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}03)
,p_plug_name=>'Body-Listagem'
,p_region_css_classes=>'hidden'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_scroll})
,p_plug_display_sequence=>10049
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}04)
,p_plug_name=>'Listagem'
,p_parent_plug_id=>wwv_flow_imp.id(${p}03)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_scroll})
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
);
-- ─── INTERACTIVE GRID ─────────────────────────────────
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}05)
,p_plug_name=>'ig-listagem'
,p_parent_plug_id=>wwv_flow_imp.id(${p}04)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_ig})
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
${igQuery.split('\n').map(l=>`'${l.replace(/'/g,"''")}',`).join('\n')}
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'${filterItems.join(',')}'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(${p}06)
,p_internal_uid=>${p}06
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_lazy_loading=>true
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>550
,p_show_icon_view=>false
,p_show_detail_view=>false${hasSetCustom ? "\n,p_javascript_code=>'setCustomConfig'" : ''}
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(${p}07)
,p_interactive_grid_id=>wwv_flow_imp.id(${p}06)
,p_static_id=>'ig${p}rpt'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>15
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(${p}08)
,p_report_id=>wwv_flow_imp.id(${p}07)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
-- ─── DA: OnclickFiltrar ───────────────────────────────
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(${p}30)
,p_name=>'OnclickFiltrar'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(${p}20)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(${p}31)
,p_event_id=>wwv_flow_imp.id(${p}30)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(${p}03)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(${p}32)
,p_event_id=>wwv_flow_imp.id(${p}30)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
-- ─── PROCESSO DML ─────────────────────────────────────
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(${p}40)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(${p}05)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'ig-listagem - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);

wwv_flow_imp.import_end(
  p_auto_install_sup_obj=>nvl(wwv_flow_application_install.get_auto_install_sup_obj,false)
);
commit;
end;`;

  const response = `Página <b>${pageName}</b> gerada (pág. <b>${p}</b>):<br>
• <b>${filterItems.length} LOVs</b>: ${filterItems.map(f=>f.replace(`P${p}_`,'')).join(', ')}<br>
• <b>Interactive Grid</b> com DML<br>
• <b>lazy_loading + stretch_columns</b>${hasSetCustom?' + setCustomConfig':''}<br>
• <b>DA OnclickFiltrar</b> + Processo DML`;

  return {sql, response};
}
