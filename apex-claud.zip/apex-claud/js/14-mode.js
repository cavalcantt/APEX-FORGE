// ── APEX FORGE — Mode ──
function switchMode(mode, el){
  document.querySelectorAll('.ntab').forEach(t => t.classList.remove('on'));
  if(el) el.classList.add('on');

  const workspace   = document.querySelector('.workspace');
  const sqlclPanel  = document.getElementById('tabSqlcl');
  const schemaPanel = document.getElementById('tabSchema');

  workspace.style.display   = mode==='ia'     ? 'grid' : 'none';
  if(sqlclPanel)  sqlclPanel.style.display  = mode==='sqlcl'  ? 'flex' : 'none';
  if(schemaPanel) schemaPanel.style.display = mode==='schema' ? 'flex' : 'none';
}

function setGenMode(mode){
  genMode = mode;
  const nova    = document.getElementById('modeNova');
  const incr    = document.getElementById('modeIncr');
  const incrCtx = document.getElementById('incrContext');
  const qp      = document.getElementById('quickPrompts');

  if(mode === 'nova'){
    nova.style.borderColor = 'var(--acc)'; nova.style.background = 'rgba(99,102,241,.15)'; nova.style.color = 'var(--t1)';
    incr.style.borderColor = 'var(--b)';  incr.style.background = 'transparent';           incr.style.color = 'var(--t3)';
    incrCtx.style.display  = 'none';
    qp.innerHTML = `
      <span class="qp" onclick="useQuick(this)">4 multifiltros + IG com DML</span>
      <span class="qp" onclick="useQuick(this)">Tela com abas + lookup cascata</span>
      <span class="qp" onclick="useQuick(this)">LOV com cursor onchange</span>
      <span class="qp" onclick="useQuick(this)">Botão Alterar via collection</span>`;
  } else {
    incr.style.borderColor = 'var(--acc)'; incr.style.background = 'rgba(99,102,241,.15)'; incr.style.color = 'var(--t1)';
    nova.style.borderColor = 'var(--b)';   nova.style.background = 'transparent';           nova.style.color = 'var(--t3)';
    incrCtx.style.display  = 'block';
    qp.innerHTML = `
      <span class="qp" onclick="useQuick(this)">Adicionar botão ao filtro</span>
      <span class="qp" onclick="useQuick(this)">Adicionar item LOV de filtro</span>
      <span class="qp" onclick="useQuick(this)">Adicionar coluna ao IG existente</span>
      <span class="qp" onclick="useQuick(this)">Criar Dynamic Action onchange</span>`;
  }
  tlog(`Modo: ${mode==='nova'?'Nova Página':'Incrementar Página'}`, 'i');
}
