// ── APEX FORGE — Saved Prompts ──

function openPromptsDrawer(){
  document.getElementById('promptsBackdrop').style.display = 'block';
  document.getElementById('promptsDrawer').classList.add('open');
  loadSavedPrompts();
}

function closePromptsDrawer(){
  document.getElementById('promptsBackdrop').style.display = 'none';
  document.getElementById('promptsDrawer').classList.remove('open');
}

async function loadSavedPrompts() {
  const listDiv = document.getElementById('promptsList');
  listDiv.innerHTML = '<div style="padding:16px;color:var(--t2);">Carregando...</div>';
  try {
    const res = await fetch('http://localhost:3007/list-prompts');
    const data = await res.json();
    if(data.success) {
      if(!data.prompts || data.prompts.length === 0) {
        listDiv.innerHTML = '<div style="padding:16px;color:var(--t2);">Nenhum prompt salvo ainda.</div>';
        return;
      }
      
      let html = '';
      // Reverse array to show newest first
      const arr = [...data.prompts].reverse();
      arr.forEach(p => {
        const preview = p.prompt.substring(0, 100) + (p.prompt.length > 100 ? '...' : '');
        html += `
          <div class="comp-item" style="cursor:pointer;" onclick="useSavedPrompt('${escHtml(p.prompt).replace(/'/g, "\\'")}')">
            <div class="comp-item-title">⭐ ${escHtml(p.title)}</div>
            <div class="comp-item-desc" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escHtml(preview)}</div>
            <div style="font-size:11px;color:var(--t2);margin-top:6px;">Salvo em: ${p.timestamp.replace('T', ' ')}</div>
          </div>
        `;
      });
      listDiv.innerHTML = html;
    } else {
      listDiv.innerHTML = `<div style="padding:16px;color:var(--red);">Erro: ${data.error}</div>`;
    }
  } catch(e) {
    listDiv.innerHTML = `<div style="padding:16px;color:var(--red);">Erro ao listar prompts: ${e.message}</div>`;
  }
}

function useSavedPrompt(promptText) {
  document.getElementById('msgInput').value = promptText;
  autoResize(document.getElementById('msgInput'));
  closePromptsDrawer();
  toast('Prompt carregado com sucesso', 's');
}

async function savePrompt(promptText) {
  const title = prompt('Digite um título para este prompt (ex: "Criar IG com DML"):');
  if(!title) return; // Cancelado
  
  try {
    const res = await fetch('http://localhost:3007/save-prompt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, prompt: promptText })
    });
    const data = await res.json();
    if(data.success) {
      toast('Prompt salvo no repositório!', 's');
    } else {
      toast('Erro ao salvar: ' + data.error, 'e');
    }
  } catch(e) {
    toast('Erro de conexão ao salvar: ' + e.message, 'e');
  }
}
