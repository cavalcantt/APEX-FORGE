// ── APEX FORGE — Init ──

// Atribui guideline padrão ao textarea
document.getElementById('glText').value = DEFAULT_GL;

// Sincroniza schema owner inicial
syncSchOwner(document.getElementById('cfgSchema').value || 'AGRICOLA');

// Sincroniza fetchAppId/fetchPageId com cfgApp/cfgPage
(function syncFetchFields(){
  const appInput  = document.getElementById('cfgApp');
  const pageInput = document.getElementById('cfgPage');
  const setFetch  = () => {
    const fa = document.getElementById('fetchAppId');
    const fp = document.getElementById('fetchPageId');
    if(fa && appInput.value)  fa.value  = appInput.value;
    if(fp && pageInput.value) fp.value  = pageInput.value;
  };
  appInput.addEventListener('input',  setFetch);
  pageInput.addEventListener('input', setFetch);
  setFetch();
})();

tlog('APEX Forge v4 pronto.','i');
tlog('Modo padrao: Gerador local instantaneo. Use IA quando precisar enriquecer a query.','i');
tlog('Terminal: rode .\\start.bat ou use o Claude CLI diretamente','w');

// Verifica servidor uma vez no startup — reutilizado em autoEnrichContext e RAG
(async function pingServer(){
  try {
    const r = await fetch('http://localhost:3007/health', { signal: AbortSignal.timeout(2000) });
    serverUp = r.ok;
    if(serverUp) tlog('Servidor local ativo ✓','s');
  } catch { serverUp = false; }
})();

// Injeta botão ▸ de expand em cada comp-card
document.querySelectorAll('.comp-card[data-comp]').forEach(card => {
  const btn = document.createElement('button');
  btn.className = 'comp-expand';
  btn.textContent = '▸';
  btn.title = 'Ver detalhes';
  btn.onclick = function(e){ expandComp(e, this); };
  const check = card.querySelector('.comp-check');
  if(check) card.insertBefore(btn, check);
});

// Inicializa sel-bar e modo IA
updateSelBar();
onAiModeChange();

// Listener do modal de conexão (fechar ao clicar fora)
document.getElementById('modalBack').addEventListener('click', e => {
  if(e.target === document.getElementById('modalBack')) closeModal();
});

// Solicita contexto APEX para a extensão e preenche os campos
window.parent.postMessage({type: 'GET_APEX_CONTEXT'}, '*');

window.addEventListener('message', e => {
  if (e.data && e.data.type === 'APEX_CONTEXT_RESPONSE') {
    let mudou = false;
    if (e.data.appId) {
      document.getElementById('cfgApp').value = e.data.appId;
      document.getElementById('cfgApp').dispatchEvent(new Event('input'));
      mudou = true;
    }
    if (e.data.pageId) {
      document.getElementById('cfgPage').value = e.data.pageId;
      document.getElementById('cfgPage').dispatchEvent(new Event('input'));
      mudou = true;
    }
    if (e.data.session) {
      const sessInput = document.getElementById('mSession');
      if(sessInput) sessInput.value = e.data.session;
    }
    
    if (mudou) {
      tlog(`Contexto APEX auto-preenchido: App ${e.data.appId} | Pág ${e.data.pageId}`, 'i');
    }
  }
});
