// ── APEX FORGE — Components ──
const COMPONENTS = {
  ig: {
    label: 'Interactive Grid',
    context: `## Interactive Grid (NATIVE_IG)
Obrigatorio em todo IG:
- p_plug_source_type: 'NATIVE_IG'
- p_lazy_loading: true
- p_javascript_code: 'setCustomConfig'
- create_ig_report_view: p_stretch_columns=true
- p_fixed_header: 'REGION' (max height 550)
- Nome da regiao: ig-[entidade] em kebab-case minusculo
- Primeira coluna: NATIVE_ROW_SELECTOR, seq 10
- create_interactive_grid + create_ig_report (PRIMARY) + create_ig_report_view (GRID) + create_ig_report_column para cada coluna
- IG editavel: p_is_editable=true, p_edit_operations='i:u:d', p_lost_update_check_type='VALUES'
- Processo DML: NATIVE_IG_DML, AFTER_SUBMIT, p_attribute_01='REGION_SOURCE', p_attribute_05/06/08='Y'
- Region template ID: 10843720933354525328`
  },
  ir: {
    label: 'Interactive Report',
    context: `## Interactive Report (NATIVE_IR)
- p_plug_source_type: 'NATIVE_IR'
- p_plug_query_options: 'DERIVED_REPORT_COLUMNS'
- create_worksheet + create_worksheet_column para cada coluna
- p_allow_save_rpt_public: 'Y', p_allow_report_categories: 'Y'
- p_show_nulls_as: '-'
- Sequencia: p_display_sequence par com p_column_type DB_COLUMN`
  },
  multifiltro: {
    label: 'CSMultifiltro',
    context: `## CSMultifiltro (PLUGIN_PL.OSTROWSKIBARTOSZ + pkg_multifiltro_apex)
Query obrigatoria:
  SELECT <cod>||' - '||<desc> D, <cod> R, <cod> CODIGO, <desc> DESCRICAO [, cols extras]
  FROM schema.tabela WHERE filtros ORDER BY 1

Display as: PLUGIN_PL.OSTROWSKIBARTOSZ.APEX.ENHANCEDLOVITEM
Atributos obrigatorios:
  p_attribute_01='RS:LDT', p_attribute_04='%D%'
  p_attribute_05='AUTOCOMPLETE:POPOUP_REPORT'
  p_attribute_06='RCC:CORSI:DRAGGABLE:COE:RPP:SIAC'
  p_attribute_09='0', p_attribute_12='720', p_attribute_13='541'
  p_attribute_14='200', p_attribute_15='20', p_attribute_17='2'

JSON popup (p_attribute_07):
  {"defaultSort":{"column":"CODIGO","direction":"asc"},
   "columns":{"CODIGO":{"heading":"Codigo","visible":true,"thAlign":"right","tdAlign":"right","width":"80px","sort":true,"filter":true},
              "DESCRICAO":{"heading":"Descricao","visible":true,"thAlign":"left","tdAlign":"left","sort":true,"filter":true}}}
  Nunca incluir D nem R no JSON.

Filtro no WHERE do IG para cada multifiltro:
  AND CASE WHEN NVL(:P{PAGE}_ITEM,'0')='0' THEN 1
           WHEN EXISTS(SELECT 1 FROM TABLE(csweb.pkg_multifiltro_apex.fn_multifiltro(:P{PAGE}_ITEM))
                       WHERE c001 = tabela.coluna) THEN 1
       END = 1`
  },
  lov_enhanced: {
    label: 'LOV Enhanced',
    context: `## LOV Enhanced (NATIVE_POPUP_LOV)
- p_display_as: 'NATIVE_POPUP_LOV'
- p_lov_display_extra: 'NO'
- p_attribute_01: 'POPUP', p_attribute_02: 'FIRST_ROWSET'
- p_attribute_04: 'N', p_attribute_05: 'Y', p_attribute_06: '0'
- Query: SELECT display_val d, return_val r FROM tabela ORDER BY 1
- Field template ID: 10843795796849525353`
  },
  lov_nativo: {
    label: 'LOV Nativo',
    context: `## LOV Nativo (NATIVE_SELECT_LIST)
- p_display_as: 'NATIVE_SELECT_LIST'
- p_lov_display_extra: 'YES' (para mostrar opcao vazia)
- p_attribute_01: 'NONE' (sem submit automatico)
- Query: SELECT display d, return_val r FROM tabela ORDER BY 1
- Para static: p_named_lov com wwv_flow_imp_shared.create_list_of_values`
  },
  lookup: {
    label: 'Lookup Cascata',
    context: `## Lookup Cascata (DA onChange)
Estrutura do PL/SQL Execute:
  DECLARE
    CURSOR c IS
      SELECT campo1, campo2, campo3
      FROM   schema.tabela
      WHERE  chave = :P{PAGE}_ITEM_PAI;
    v_rec c%ROWTYPE;
  BEGIN
    OPEN c; FETCH c INTO v_rec; CLOSE c;
    IF c%FOUND THEN
      :P{PAGE}_FILHO1 := v_rec.campo1;
      :P{PAGE}_FILHO2 := v_rec.campo2;
    ELSE
      :P{PAGE}_FILHO1 := NULL;
      :P{PAGE}_FILHO2 := NULL;
    END IF;
  END;

Atributos DA:
  p_attribute_02: lista dos itens a submeter (pai + todos usados no cursor)
  p_attribute_03: lista dos itens retornados (todos setados)
  p_wait_for_result: 'Y'
  execute_on_page_init: 'Y' se a pagina ja abre com valor preenchido`
  },
  abas: {
    label: 'Abas (TABINDEX)',
    context: `## Sistema de Abas com TABINDEX
Estrutura:
1. Item hidden P{PAGE}_TABINDEX (NUMBER, default 1, source DB_COLUMN ou STATIC)
2. Botoes de aba: p_button_css_classes='cs-Button--tabs:t-Button--gapLeft'
   p_button_action='PREVIOUS'
3. DA onClick cada botao N:
   - SET_VALUE: P{PAGE}_TABINDEX = N (tipo: STATIC_ASSIGNMENT)
4. DA onChange P{PAGE}_TABINDEX EQUALS N:
   - ADD_CLASS t-Button--hot ao botao N
   - REMOVE_CLASS t-Button--hot dos outros botoes
   - SHOW regiao Body-N (affected: REGION)
   - HIDE regioes Body-outros
Sequencias de regioes: Controle de abas(10029), Body-1(10039), Body-2(10049), Body-3(10059)...`
  },
  readonly: {
    label: 'Read-only Condicional',
    context: `## Read-only Condicional (fn_page_is_readonly)
Na create_page adicionar:
  p_read_only_when_type => 'EXPRESSION'
  p_read_only_when      => 'csweb.pkg_apex_scaffold.fn_page_is_readonly'
  p_read_only_when2     => 'PLSQL'
Isso torna toda a pagina read-only baseado na funcao de controle.`
  },
  alterar: {
    label: 'Alterar via Collection',
    context: `## Alterar via Collection (FOS)
Fluxo no botao ALTERAR (DA onClick):
1. FOS.EXECUTE_PLSQL:
   BEGIN csweb.pkg_apex_collection.pr_create_collection('ALTERAR'); END;

2. FOS.INTERACTIVE_GRID_PROCESS_ROWS:
   p_target_action: 'CHECKED'
   p_collection_name: 'ALTERAR'
   PL/SQL: BEGIN csweb.pkg_apex_collection.pr_add_member(
     p_collection_name=>'ALTERAR', p_c001=>:COL_ID1, p_c002=>:COL_ID2); END;

3. FOS.REDIRECT:
   URL: f?p=&APP_ID.:{PAGINA_DIALOG}:&SESSION.:::{ITEMS}:{VALUES}
   Passar IDs necessarios via substituicao`
  },
  fos: {
    label: 'FOS Redirect',
    context: `## FOS Redirect (PLUGIN_COM.FOS.REDIRECT)
- p_display_as: 'PLUGIN_COM.FOS.REDIRECT'
- URL pattern: f?p=&APP_ID.:{PAGE_ALIAS}:&SESSION.:::{ITEM1,ITEM2}:{VAL1,VAL2}
- Para dialog: adicionar ,RP,{PAGE_ALIAS} no clear cache
- Usado apos processar collection ou como navegacao principal
- p_attribute_01: URL completa com substituicoes APEX`
  },
  proc_prerender: {
    label: 'Processo Pre-Rendering',
    context: `## Processo Pre-Rendering (BEFORE_HEADER)
Estrutura:
  wwv_flow_imp_page.create_page_process(
   p_process_point => 'BEFORE_HEADER'
  ,p_process_type  => 'NATIVE_PLSQL'
  ,p_process_name  => 'pre-rendering'
  ,p_process_sql_clob => wwv_flow_string.join(wwv_flow_t_varchar2(
  'DECLARE',
  '  CURSOR c IS',
  '    SELECT campo1, campo2',
  '    FROM   schema.tabela',
  '    WHERE  chave = :P{PAGE}_ITEM_FILTRO',
  '    AND    cod_empresa = :G_COD_EMPRESA;',
  '  v_rec c%ROWTYPE;',
  'BEGIN',
  '  OPEN c; FETCH c INTO v_rec; CLOSE c;',
  '  IF c%FOUND THEN',
  '    :P{PAGE}_ITEM1 := v_rec.campo1;',
  '    :P{PAGE}_ITEM2 := v_rec.campo2;',
  '  END IF;',
  'END;'))
  );
Usar para: carregar dados na abertura da pagina, pre-popular itens, buscar defaults.`
  },
  proc_submit: {
    label: 'Processo After Submit',
    context: `## Processo After Submit (AFTER_SUBMIT)
Estrutura:
  wwv_flow_imp_page.create_page_process(
   p_process_point => 'AFTER_SUBMIT'
  ,p_process_type  => 'NATIVE_PLSQL'
  ,p_process_name  => 'salvar'
  ,p_error_display_location => 'INLINE_IN_NOTIFICATION'
  ,p_process_sql_clob => wwv_flow_string.join(wwv_flow_t_varchar2(
  'BEGIN',
  '  IF :P{PAGE}_ID IS NULL THEN',
  '    INSERT INTO schema.tabela (col1, col2)',
  '    VALUES (:P{PAGE}_ITEM1, :P{PAGE}_ITEM2);',
  '  ELSE',
  '    UPDATE schema.tabela SET col1=:P{PAGE}_ITEM1',
  '    WHERE id=:P{PAGE}_ID;',
  '  END IF;',
  '  COMMIT;',
  'EXCEPTION WHEN OTHERS THEN',
  '  ROLLBACK;',
  '  raise_application_error(-20001, SQLERRM);',
  'END;'))
  );`
  },
  proc_ajax: {
    label: 'Processo AJAX (On Demand)',
    context: `## Processo AJAX / On Demand
Estrutura:
  wwv_flow_imp_page.create_page_process(
   p_process_point => 'AJAX_CALLBACK'
  ,p_process_type  => 'NATIVE_PLSQL'
  ,p_process_name  => 'NOME_PROCESSO'
  ,p_process_sql_clob => wwv_flow_string.join(wwv_flow_t_varchar2(
  'DECLARE',
  '  v_param VARCHAR2(4000) := apex_application.g_x01;',
  '  v_result VARCHAR2(32767);',
  'BEGIN',
  '  -- logica aqui usando v_param',
  '  v_result := \'{"status":"ok","data":"\'||v_param||\'"}\';',
  '  htp.p(v_result);',
  'END;'))
  );
Chamada JS: apex.server.process("NOME_PROCESSO", {x01: valor}, {success: function(r){...}});`
  },
  proc_validation: {
    label: 'Validacao',
    context: `## Validacao (AFTER_SUBMIT)
Estrutura:
  wwv_flow_imp_page.create_page_validation(
   p_validation_sequence      => 10
  ,p_validation_name          => 'val_campo_obrigatorio'
  ,p_validation_type          => 'PLSQL_EXPRESSION'
  ,p_validation                => ':P{PAGE}_ITEM IS NOT NULL'
  ,p_error_message            => 'Campo obrigatorio nao preenchido.'
  ,p_error_display_location   => 'INLINE_WITH_FIELD_AND_NOTIFICATION'
  ,p_associated_item          => wwv_flow_imp.id({ITEM_ID})
  );
Para validacao complexa usar PLSQL_FUNCTION_BODY retornando NULL (ok) ou mensagem de erro.`
  }
};

function openDrawer(){
  document.getElementById('compBackdrop').classList.add('open');
  document.getElementById('compDrawer').classList.add('open');
}
function closeDrawer(){
  document.getElementById('compBackdrop').classList.remove('open');
  document.getElementById('compDrawer').classList.remove('open');
}
function toggleComp(el){
  if (typeof fastLocalAi !== 'undefined' && fastLocalAi) {
    // Modo Local: Abre o Wizard em vez de selecionar
    openCompWizard(el.dataset.comp);
    closeDrawer();
    return;
  }
  el.classList.toggle('on');
  updateCompBadge();
  updateSelBar();
}
function clearComps(){
  document.querySelectorAll('.comp-card.on').forEach(c=>c.classList.remove('on'));
  updateCompBadge();
  updateSelBar();
}
function getSelectedComps(){
  return [...document.querySelectorAll('.comp-card.on')].map(c=>c.dataset.comp);
}
function updateCompBadge(){
  const sel = getSelectedComps();
  const badge = document.getElementById('compBadge');
  if(sel.length === 0){
    badge.textContent = '⊞ Componentes';
    badge.style.borderColor = 'rgba(99,102,241,.3)';
  } else {
    const names = sel.map(k => COMPONENTS[k]?.label || k);
    badge.textContent = '⊞ ' + names.slice(0,3).join(', ') + (names.length > 3 ? ' +'+( names.length-3) : '');
    badge.style.borderColor = 'var(--acc)';
  }
}
function getCompContext(){
  const sel = getSelectedComps();
  if(sel.length === 0) return '';
  return '\n\nCOMPONENTES SELECIONADOS (usar estes padroes exatos):\n' +
    sel.map(k => COMPONENTS[k]?.context || '').join('\n\n');
}

function expandComp(e, btn){
  e.stopPropagation();
  const card = btn.closest('.comp-card');
  const key  = card.dataset.comp;
  let detail = document.getElementById('cdetail-' + key);
  if(!detail){
    detail = document.createElement('div');
    detail.className = 'comp-detail';
    detail.id = 'cdetail-' + key;
    const comp = COMPONENTS[key];
    if(comp){
      detail.innerHTML =
        `<div class="comp-detail-title">${comp.label}</div>` +
        escHtml(comp.context);
    }
    card.after(detail);
  }
  const isOpen = detail.classList.toggle('open');
  btn.classList.toggle('open', isOpen);
  btn.textContent = isOpen ? '▾' : '▸';
}

function removeComp(key){
  const card = document.querySelector(`.comp-card[data-comp="${key}"]`);
  if(card) card.classList.remove('on');
  updateCompBadge();
  updateSelBar();
}

function updateSelBar(){
  const sel = getSelectedComps();
  const bar   = document.getElementById('selBar');
  const empty = document.getElementById('selBarEmpty');
  bar.querySelectorAll('.sel-pill').forEach(p => p.remove());
  if(sel.length === 0){
    empty.style.display = 'flex';
    document.getElementById('optsBadge').textContent = 'Nenhum componente';
    return;
  }
  empty.style.display = 'none';
  sel.forEach(key => {
    const comp = COMPONENTS[key];
    if(!comp) return;
    const pill = document.createElement('span');
    pill.className = 'sel-pill';
    pill.dataset.comp = key;
    pill.innerHTML = `${comp.label}<span class="sel-pill-x" onclick="removeComp('${key}')">×</span>`;
    bar.appendChild(pill);
  });
  const names = sel.map(k => COMPONENTS[k]?.label || k);
  document.getElementById('optsBadge').textContent =
    names.slice(0,2).join(' · ') + (names.length > 2 ? ` +${names.length-2}` : '');
}

// ── WIZARD LOCAL ──
let currentWizComp = null;

function openCompWizard(compKey) {
  currentWizComp = compKey;
  const comp = COMPONENTS[compKey] || { label: compKey };
  document.getElementById('wizTitle').textContent = `Assistente: ${comp.label}`;
  
  const body = document.getElementById('wizBody');
  body.innerHTML = '';
  
  if (compKey.includes('ig') || compKey.includes('ir')) {
    body.innerHTML = `
      <div><label class="mfl">Nome da Região Pai</label><input class="mfi" id="wizRegion" placeholder="Ex: Detalhes do Pedido"></div>
      <div><label class="mfl">Query SQL</label><textarea class="mfi" id="wizQuery" rows="4" placeholder="SELECT * FROM tabela"></textarea></div>
    `;
  } else if (compKey.includes('multifiltro') || compKey.includes('lov')) {
    body.innerHTML = `
      <div><label class="mfl">Nome do Filtro/Campo (sem o P_)</label><input class="mfi" id="wizLabel" placeholder="Ex: FAZENDA"></div>
      <div><label class="mfl">Região de destino</label><input class="mfi" id="wizRegion" placeholder="Ex: Filtros"></div>
      <div><label class="mfl">Query SQL do LOV</label><textarea class="mfi" id="wizQuery" rows="3" placeholder="SELECT cod, desc FROM tabela"></textarea></div>
    `;
  } else if (compKey === 'lookup') {
    body.innerHTML = `
      <div><label class="mfl">Item Pai (Trigger)</label><input class="mfi" id="wizParent" placeholder="Ex: P1_FAZENDA"></div>
      <div><label class="mfl">Item Filho (Alvo)</label><input class="mfi" id="wizChild" placeholder="Ex: P1_ZONA"></div>
      <div><label class="mfl">Query SQL do Cursor</label><textarea class="mfi" id="wizQuery" rows="3" placeholder="SELECT zona FROM tabela WHERE fazenda = :P1_FAZENDA"></textarea></div>
    `;
  } else {
    body.innerHTML = `
      <div style="font-size:11px;color:var(--t2);">Este componente não suporta o Wizard Local. Digite manualmente no prompt.</div>
    `;
  }
  
  document.getElementById('wizModalBack').style.display = 'flex';
}

function closeWizModal() {
  document.getElementById('wizModalBack').style.display = 'none';
  currentWizComp = null;
}

function generateWizSnippet() {
  if (!currentWizComp) return;
  
  const p = parseInt(document.getElementById('cfgPage').value) || 999;
  const appId = document.getElementById('cfgApp').value || '100';
  const tmpl = getTemplates(appId);
  const pageSql = document.getElementById('cfgPageSQL')?.value || '';
  
  function findRegionId(regionName) {
    if (!regionName || !pageSql) return `wwv_flow_imp.id(${p}01)`;
    const safeRegex = regionName.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const match = pageSql.match(new RegExp(`p_id=>wwv_flow_imp\\.id\\((\\d+)\\)[\\s\\S]*?p_plug_name=>'[^']*${safeRegex}[^']*'`, 'i'));
    if (match) return `wwv_flow_imp.id(${match[1]})`;
    return `wwv_flow_imp.id(${p}01)`;
  }

  let genId = Math.floor(Math.random() * 90) + 10;
  let sql = '';
  
  if (currentWizComp.includes('ig') || currentWizComp.includes('ir')) {
    const regionName = document.getElementById('wizRegion').value || 'Listagem';
    const query = document.getElementById('wizQuery').value || 'SELECT 1 FROM DUAL';
    
    // Create region and then the IG
    sql = `wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(${p}${genId}01)
,p_plug_name=>'${regionName}'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(${tmpl.region_ig})
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
${query.split('\\n').map(l=>`'${l.replace(/'/g,"''")}',`).join('\\n')}
''))
,p_plug_source_type=>'NATIVE_IG'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(${p}${genId}02)
,p_internal_uid=>${p}${genId}02
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lazy_loading=>true
);`;

  } else if (currentWizComp.includes('multifiltro') || currentWizComp.includes('lov')) {
    const rawLabel = document.getElementById('wizLabel').value || 'FILTRO';
    const itemName = rawLabel.toUpperCase().startsWith('P') ? rawLabel.toUpperCase() : `P${p}_${rawLabel.toUpperCase()}`;
    const regionName = document.getElementById('wizRegion').value || 'Filtros';
    const query = document.getElementById('wizQuery').value || 'SELECT cod, desc FROM tabela';
    const parentId = findRegionId(regionName);
    
    sql = `wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(${p}${genId})
,p_name=>'${itemName}'
,p_item_sequence=>10
,p_item_plug_id=>${parentId}
,p_prompt=>'${rawLabel}'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
${query.split('\\n').map(l=>`'${l.replace(/'/g,"''")}',`).join('\\n')}
''))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(${tmpl.field_template})
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
);`;

  } else if (currentWizComp === 'lookup') {
    const parent = document.getElementById('wizParent').value || `P${p}_PAI`;
    const child = document.getElementById('wizChild').value || `P${p}_FILHO`;
    const query = document.getElementById('wizQuery').value || 'SELECT 1 FROM DUAL';
    
    sql = `-- Cursor (Lookup Cascata) para ${child} disparado por ${parent}
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(${p}${genId}30)
,p_name=>'Cascata_${child}'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_item=>'${parent}'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(${p}${genId}31)
,p_event_id=>wwv_flow_imp.id(${p}${genId}30)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  CURSOR c_dados IS',
${query.split('\\n').map(l=>`'    ${l.replace(/'/g,"''")}',`).join('\\n')}
'  v_dados c_dados%ROWTYPE;',
'BEGIN',
'  OPEN c_dados;',
'  FETCH c_dados INTO v_dados;',
'  IF c_dados%FOUND THEN',
'    :${child} := v_dados.VALOR;',
'  ELSE',
'    :${child} := NULL;',
'  END IF;',
'  CLOSE c_dados;',
'END;'
))
,p_attribute_02=>'${parent}'
,p_attribute_03=>'${child}'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);`;
  }
  
  closeWizModal();
  
  if (sql) {
    const finalSql = `begin\n${sql}\ncommit;\nend;`;
    addMsg(`Componente **${COMPONENTS[currentWizComp]?.label}** gerado!`, 'ai', finalSql, `Gerado via Assistente: ${currentWizComp}`);
  }
}

