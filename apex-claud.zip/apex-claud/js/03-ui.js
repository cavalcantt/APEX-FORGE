// ── APEX FORGE — UI ──
function escHtml(s){
  return s
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

function tlog(msg,type='i'){
  const body=document.getElementById('termBody');
  const d=document.createElement('div');d.className='tlog';
  const labels={i:'INFO',s:'DONE',e:'ERROR',w:'WARN',r:'RUN'};
  const t=getT();
  d.innerHTML=`<span class="tlog-t">${t}</span><span class="tlog-k ${type}">${labels[type]}</span><span class="tlog-m">${msg}</span>`;
  body.appendChild(d);body.scrollTop=body.scrollHeight;
}
function getT(){const s=~~((Date.now()-t0)/1000);return String(~~(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}

function prog(pct,label){
  document.getElementById('pFill').style.width=pct+'%';
  document.getElementById('pPct').textContent=pct+'%';
  document.getElementById('pLabel').textContent=label;
}

function toast(msg, type='i'){
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;top:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
    document.body.appendChild(container);
  }
  const colors = {s:'var(--grn)',e:'var(--red)',w:'var(--ylw)',i:'var(--acc3)'};
  const icons  = {s:'✓',e:'✗',w:'⚠',i:'·'};
  const t = document.createElement('div');
  t.style.cssText = `background:var(--bg2,#1e1e2e);border:1px solid ${colors[type]||colors.i};color:var(--t1,#cdd6f4);padding:10px 16px;border-radius:8px;font-size:13px;display:flex;gap:8px;align-items:center;max-width:320px;box-shadow:0 4px 16px #0008;animation:fadeup .2s ease;pointer-events:none;`;
  t.innerHTML = `<span style="color:${colors[type]||colors.i};flex-shrink:0">${icons[type]||'·'}</span><span>${msg}</span>`;
  container.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .4s'; setTimeout(()=>t.remove(),400); }, 3000);
}

function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

function autoResize(el){
  el.style.height='auto';
  el.style.height=Math.min(el.scrollHeight,160)+'px';
}
function handleKey(e){
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMsg();}
}
function useQuick(el){
  document.getElementById('msgInput').value = el.textContent;
  autoResize(document.getElementById('msgInput'));
}

function toggleRightPanel() {
  const ws = document.querySelector('.workspace');
  const btn = document.getElementById('btnToggleRP');
  if (ws.classList.contains('rp-collapsed')) {
    ws.classList.remove('rp-collapsed');
    btn.innerHTML = '▼ Ocultar Configs';
  } else {
    ws.classList.add('rp-collapsed');
    btn.innerHTML = '▲ Mostrar Configs';
  }
}
