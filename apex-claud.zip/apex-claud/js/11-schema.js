// ── APEX FORGE — Schema ──
function syncSchOwner(val){
  const el = document.getElementById('schOwner');
  if(el) el.value = val.toUpperCase();
}

async function schemaLoadTables(){
  const owner = (document.getElementById('schOwner').value || '').trim().toUpperCase();
  if(!owner){ toast('Informe o owner','w'); return; }

  schCurrentOwner = owner;
  schCurrentTable = '';
  schColumns      = [];
  document.getElementById('schTableList').innerHTML =
    '<div style="padding:12px;color:var(--t3);font-family:var(--mono);font-size:11px;text-align:center;">Consultando banco...</div>';
  document.getElementById('schTableCount').textContent = '';
  document.getElementById('schTableTitle').textContent = 'Selecione um objeto';
  document.getElementById('schColMeta').textContent    = '';
  document.getElementById('schColList').innerHTML      = '';
  document.getElementById('schUseBtn').style.display   = 'none';

  if(schTablesCache[owner]){
    schAllTables = schTablesCache[owner];
    document.getElementById('schTableCount').textContent = `${schAllTables.length} tabelas`;
    schRenderTables(schAllTables);
    tlog(`Schema tables cache: ${owner} (${schAllTables.length} tabelas)`, 'i');
    toast(`${schAllTables.length} tabelas em ${owner} (cache)`, 's');
    return;
  }

  try {
    const res  = await fetch('http://localhost:3007/schema-tables', {
      method:'POST', headers: getForgeHeaders(),
      body: JSON.stringify({owner}), signal: AbortSignal.timeout(120000)
    });
    const data = await res.json();
    if(!data.success) throw new Error(data.error || 'Erro ao carregar tabelas');

    schAllTables = data.tables || [];
    schTablesCache[owner] = schAllTables;
    document.getElementById('schTableCount').textContent = `${schAllTables.length} tabelas`;
    schRenderTables(schAllTables);
    toast(`${schAllTables.length} tabelas em ${owner}`, 's');
  } catch(e){
    document.getElementById('schTableList').innerHTML =
      `<div style="padding:12px;color:var(--red);font-family:var(--mono);font-size:11px;">Erro: ${escHtml(e.message)}<br><br>Servidor ativo? Rode start.bat</div>`;
    toast('Erro: '+e.message, 'e');
  }
}

function schRenderTables(tables){
  const listEl = document.getElementById('schTableList');
  if(!tables.length){
    listEl.innerHTML = '<div style="padding:10px;color:var(--t3);font-family:var(--mono);font-size:11px;text-align:center;">Nenhum objeto encontrado</div>';
    return;
  }
  const icons = { 'TABLE':'🗄️', 'VIEW':'👁️', 'TRIGGER':'⚡', 'PACKAGE':'📦', 'PROCEDURE':'⚙️', 'FUNCTION':'ƒ' };
  listEl.innerHTML = tables.map(t => {
    const active = t.name === schCurrentTable;
    const icon = icons[t.type] || '📄';
    return `<div onclick="schemaLoadObject('${t.type}', '${t.name}')"
      style="padding:7px 10px;border-radius:7px;cursor:pointer;margin-bottom:2px;
             font-size:12px;font-family:var(--mono);display:flex;align-items:center;gap:6px;
             background:${active?'rgba(99,102,241,.15)':'transparent'};
             border:1px solid ${active?'var(--acc)':'transparent'};
             color:${active?'var(--t1)':'var(--t2)'};transition:all .1s;"
      onmouseover="if('${t.name}'!==schCurrentTable)this.style.background='rgba(255,255,255,.04)'"
      onmouseout="if('${t.name}'!==schCurrentTable)this.style.background='transparent'">
      <span style="font-size:14px;line-height:1;">${icon}</span>
      <span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escHtml(t.name)}</span>
    </div>`;
  }).join('');
}

function schemaFilter(){
  const q = document.getElementById('schSearch').value.toLowerCase();
  const filtered = schAllTables.filter(t => t.name.toLowerCase().includes(q));
  document.getElementById('schTableCount').textContent = `${filtered.length} / ${schAllTables.length} objetos`;
  schRenderTables(filtered);
}

async function schemaLoadObject(objType, objName){
  schCurrentType = objType;
  schCurrentTable = objName;
  const owner = schCurrentOwner;
  const cacheKey = `${owner}.${objName}`;

  const q = document.getElementById('schSearch').value.toLowerCase();
  schRenderTables(schAllTables.filter(t => !q || t.name.toLowerCase().includes(q)));

  document.getElementById('schTableTitle').textContent  = `${owner}.${objName} (${objType})`;
  document.getElementById('schColMeta').textContent     = 'Carregando...';
  document.getElementById('schColList').innerHTML       = '';
  document.getElementById('schUseBtn').style.display    = 'none';

  if (objType === 'TABLE' || objType === 'VIEW') {
    if(schColumnsCache[cacheKey]){
      schColumns = schColumnsCache[cacheKey];
      document.getElementById('schColMeta').textContent  = `${schColumns.length} colunas`;
      document.getElementById('schUseBtn').style.display = 'block';
      schRenderColumns(schColumns);
      return;
    }
    try {
      const res  = await fetch('http://localhost:3007/schema-columns', {
        method:'POST', headers: getForgeHeaders(),
        body: JSON.stringify({owner, table: objName}), signal: AbortSignal.timeout(120000)
      });
      const data = await res.json();
      if(!data.success) throw new Error(data.error || 'Erro ao carregar colunas');
      schColumns = data.columns || [];
      schColumnsCache[cacheKey] = schColumns;
      document.getElementById('schColMeta').textContent  = `${schColumns.length} colunas`;
      document.getElementById('schUseBtn').style.display = 'block';
      schRenderColumns(schColumns);
    } catch(e){
      document.getElementById('schColMeta').textContent = 'Erro';
      toast('Erro ao carregar colunas: '+e.message, 'e');
    }
  } else {
    document.getElementById('schColMeta').textContent = 'Código Fonte';
    schColumns = [];
    try {
      const res = await fetch('http://localhost:3007/schema-source', {
        method:'POST', headers: getForgeHeaders(),
        body: JSON.stringify({owner, name: objName, type: objType}), signal: AbortSignal.timeout(120000)
      });
      const data = await res.json();
      if(!data.success) throw new Error(data.error || 'Erro ao carregar fonte');
      schSource = data.source || '';
      document.getElementById('schColList').innerHTML = `<pre style="font-size:10px;font-family:var(--mono);color:var(--t2);overflow-x:auto;padding:10px;background:var(--bg3);border-radius:8px;">${escHtml(schSource)}</pre>`;
      document.getElementById('schUseBtn').style.display = 'block';
    } catch(e){
      document.getElementById('schColMeta').textContent = 'Erro';
      toast('Erro ao carregar fonte: '+e.message, 'e');
    }
  }
}

function schRenderColumns(columns){
  document.getElementById('schColList').innerHTML = columns.map(col => {
    const notNull  = col.nullable === 'N';
    const hasDefault = col.default && col.default.trim() && col.default.trim() !== ' ';
    return `<div style="background:var(--bg3);border:1px solid var(--b);border-radius:8px;padding:9px 12px;"
             title="${notNull?'NOT NULL':'nullable'}${hasDefault?' | DEFAULT: '+col.default.trim():''}">
      <div style="font-size:11px;font-weight:600;color:var(--t1);font-family:var(--mono);">${escHtml(col.name)}</div>
      <div style="font-size:10px;color:var(--acc3);font-family:var(--mono);margin-top:2px;">${escHtml(col.type)}</div>
      <div style="font-size:9px;color:${notNull?'var(--red)':'var(--t3)'};margin-top:3px;">${notNull?'NOT NULL':'nullable'}</div>
      ${hasDefault?`<div style="font-size:9px;color:var(--t3);font-family:var(--mono);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">default: ${escHtml(col.default.trim())}</div>`:''}
    </div>`;
  }).join('');
}

function schemaInsertContext(){
  if(!schCurrentTable){ toast('Selecione um objeto primeiro','w'); return; }

  let ctx = '';
  if(schCurrentType === 'TABLE' || schCurrentType === 'VIEW'){
    if(!schColumns.length){ toast('Nenhuma coluna disponível','w'); return; }
    const colDefs = schColumns.map(c => `  ${c.name.padEnd(30)} ${c.type}${c.nullable==='N'?' NOT NULL':''}`).join('\n');
    ctx = `\n\n-- Estrutura da tabela/view ${schCurrentOwner}.${schCurrentTable}:\n-- Colunas disponíveis:\n/*\n${colDefs}\n*/\n\n`;
  } else {
    if(!schSource){ toast('Nenhum código fonte disponível','w'); return; }
    ctx = `\n\n-- Código fonte de ${schCurrentOwner}.${schCurrentTable} (${schCurrentType}):\n\`\`\`sql\n${schSource}\n\`\`\`\n\n`;
  }

  switchMode('ia', document.getElementById('ntab-ia'));
  const input = document.getElementById('msgInput');
  input.value = (input.value.trimEnd() + ctx).trimStart();
  autoResize(input);
  input.focus();
  toast(`Estrutura de ${schCurrentTable} inserida no prompt`, 's');
}

async function fetchApexPage(){
  const appId  = (document.getElementById('fetchAppId').value  || document.getElementById('cfgApp').value  || '').trim();
  const pageId = (document.getElementById('fetchPageId').value || document.getElementById('cfgPage').value || '').trim();

  if(!appId || !pageId){
    toast('Preencha App ID e Página','w');
    return;
  }

  const iconEl   = document.getElementById('fetchIcon');
  const labelEl  = document.getElementById('fetchLabel');
  const statusEl = document.getElementById('fetchStatus');

  iconEl.textContent  = '⏳';
  labelEl.textContent = 'Importando...';
  statusEl.textContent = 'Consultando banco...';
  statusEl.style.color = 'var(--ylw)';

  const cacheKey = `${appId}.${pageId}`;
  if(apexPageCache[cacheKey]){
    document.getElementById('cfgPageSQL').value = apexPageCache[cacheKey].sql;
    const sql = apexPageCache[cacheKey].sql;
    const lineCount = sql.split('\n').length;
    statusEl.textContent = `Cache - ${lineCount} linhas`;
    statusEl.style.color = 'var(--grn)';
    iconEl.textContent  = 'â¬‡';
    labelEl.textContent = 'Importar do banco';
    toast(`Pagina ${pageId} carregada do cache`, 's');
    tlog(`Pagina App=${appId} Page=${pageId} carregada do cache: ${lineCount} linhas`, 'i');
    return;
  }

  try {
    const res  = await fetch('http://localhost:3007/fetch-apex-page', {
      method: 'POST',
      headers: getForgeHeaders(),
      body: JSON.stringify({ appId: parseInt(appId), pageId: parseInt(pageId) }),
      signal: AbortSignal.timeout(70000)
    });
    const data = await res.json();

    if(!data.success) throw new Error(data.error || 'Erro ao importar');

    document.getElementById('cfgPageSQL').value = data.sql;
    apexPageCache[cacheKey] = { sql: data.sql, mode: data.mode };

    const isExport  = data.mode === 'export';
    const charCount = data.sql.length;
    const lineCount = data.sql.split('\n').length;

    statusEl.textContent = isExport
      ? `✓ Export completo — ${lineCount} linhas (${Math.round(charCount/1024)}KB)`
      : `✓ Resumo via dicionário — ${lineCount} linhas`;
    statusEl.style.color = 'var(--grn)';

    toast(`Página ${pageId} importada (${lineCount} linhas)`, 's');
    tlog(`Pagina App=${appId} Page=${pageId} importada: ${lineCount} linhas, modo=${data.mode}`, 's');

  } catch(e){
    statusEl.textContent = '✗ ' + e.message;
    statusEl.style.color = 'var(--red)';
    toast('Erro ao importar: '+e.message, 'e');
    tlog('Erro fetchApexPage: '+e.message, 'e');
  } finally {
    iconEl.textContent  = '⬇';
    labelEl.textContent = 'Importar do banco';
  }
}
