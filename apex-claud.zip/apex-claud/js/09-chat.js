// ── APEX FORGE — Chat ──
let chatHistory = [];
function addMsg(text, role, sql='', originalPrompt=''){
  if(text && text !== 'Chat limpo. Pronto para uma nova tela!') {
    chatHistory.push({ role, text, sql });
    // Mantém as últimas 20 mensagens para não estourar tokens abusivamente (isso já é o "máximo" razoável)
    if(chatHistory.length > 20) chatHistory.shift();
  }
  const chat = document.getElementById('chat');
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  const avatar = role==='user'
    ? '<div class="msg-avatar">AC</div>'
    : '<div class="msg-avatar">⚡</div>';
  let sqlHtml = '';
  if(sql){
    lastSQL = sql;
    let saveBtn = '';
    if(originalPrompt) {
      const escaped = escHtml(originalPrompt).replace(/'/g, "\\'").replace(/\n/g, '\\n');
      saveBtn = `<button class="sql-copy" style="color:var(--ylw)" onclick="savePrompt('${escaped}')">⭐ salvar prompt</button>`;
    }
    sqlHtml = `<div class="sql-block">
      <div class="sql-block-head">
        <span class="sql-block-title">SQL gerado</span>
        <div style="display:flex;gap:8px;">
          ${saveBtn}
          <button class="sql-copy" onclick="copiarSQL()">⎘ copiar</button>
        </div>
      </div>
      <div class="sql-code">${escHtml(sql)}</div>
    </div>
    <button class="apply-btn" onclick="aplicarSQL()">▶ Aplicar no APEX</button>`;
  }
  div.innerHTML = `${avatar}<div class="msg-bubble">${text}${sqlHtml}</div>`;
  div.querySelector('.apply-btn')?.replaceChildren(document.createTextNode('Aplicar via SQLcl'));
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
  return div;
}

function showTyping(){
  const chat = document.getElementById('chat');
  const div = document.createElement('div');
  div.className = 'msg ai';
  div.id = 'typing-indicator';
  div.innerHTML = '<div class="msg-avatar">⚡</div><div class="msg-bubble"><div class="typing"><span></span><span></span><span></span></div></div>';
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}
function hideTyping(){ document.getElementById('typing-indicator')?.remove(); }

function clearChat(){
  document.getElementById('chat').innerHTML = '';
  chatHistory = [];
  addMsg('Chat limpo. Pronto para uma nova tela!','ai');
}
