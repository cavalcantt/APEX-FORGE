// ── APEX FORGE — Templates ──
const APP_TEMPLATES = {
  // App 40154 — CS Controle de Serviços Agrícolas
  '40154': {
    region_html:    '10843665119496525312',
    region_scroll:  '10843725562954525329',
    region_ig:      '10843720933354525328',
    btn_no_icon:    '10843798411754525354',
    btn_icon:       '10843798585753525354',
    field_template: '10843795796849525353',
    lov_cascade:    false,
    setcustomconfig: true,
    readonly_fn:    true,          // tem pkg_apex_scaffold
  },
  // App 255 — Teste Forge
  '255': {
    region_html:    '900163944096100532',
    region_scroll:  '900222450670100614',
    region_ig:      '900215313474100611',
    btn_no_icon:    '900304182582100668',
    btn_icon:       '900304182582100668',
    field_template: '900301509968100663',
    lov_cascade:    true,
    setcustomconfig: false,
    readonly_fn:    false,         // pkg_apex_scaffold não existe nesse ambiente
  }
};

function getTemplates(appId){
  return APP_TEMPLATES[appId] || APP_TEMPLATES['40154'];
}

function getWorkspaceId(appId){
  const map = {
    '255':   '3805326530312898',
    '40154': '3805326530312898',
    '40156': '3805326530312898',
  };
  return map[appId] || '3805326530312898';
}
