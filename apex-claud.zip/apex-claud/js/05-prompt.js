// -- APEX FORGE -- Prompt --
const DEFAULT_GL = `# Guideline - App 40154 CS Agricola

## Estrutura de regioes (sequencia obrigatoria)
Filtros(10009) -> Controle de abas(10029) -> Body-*(10039+) -> somenteAtivos(10059)

## Template IDs fixos
- Region HTML:     10843665119496525312
- Region scroll:   10843725562954525329
- IG region:       10843720933354525328
- Button s/icone:  10843798411754525354
- Button c/icone:  10843798585753525354
- Field template:  10843795796849525353

## Interactive Grid -- OBRIGATORIO
- p_lazy_loading:       true
- p_javascript_code:    'setCustomConfig'
- p_stretch_columns:    true (no ig_report_view)
- p_fixed_header:       'REGION' max 550
- Nome regiao:          ig-[entidade] (kebab minusculo)
- Row Selector seq 10

## Multifiltro -- padrao query
SELECT <cod> || ' - ' || <desc> AS D, <cod> AS R,
       <cod> CODIGO, <desc> DESCRICAO [, outras colunas]
FROM schema.tabela WHERE filtros

## JSON popup LOV Enhanced
- CODIGO: direita, 80px, sort+filter
- DESCRICAO: esquerda, sort+filter
- defaultSort: CODIGO asc
- Nunca incluir R nem D no JSON
- Dimensoes: 720x541, 20 rows, 2 colunas busca

## Multifiltro na query do IG
and case when nvl(:P{PAGE}_ITEM,'0')='0' then 1
         when exists(select 1 from table(csweb.pkg_multifiltro_apex.fn_multifiltro(:P{PAGE}_ITEM))
                     where c001=tabela.coluna) then 1
     end=1

## Lookup cascata
- DECLARE cursor WHERE :ITEM_PAI -> OPEN/FETCH/CLOSE -> IF %FOUND -> seta filhos / ELSE -> NULL
- p_attribute_02: items to submit (pai + usados no cursor)
- p_attribute_03: items to return (todos setados)
- p_wait_for_result: Y | execute_on_page_init: Y quando tela ja abre com valor

## Sistema de abas (TABINDEX)
- Item hidden P{PAGE}_TABINDEX
- onClick aba -> SET_VALUE TABINDEX = indice
- onChange TABINDEX EQUALS indice -> ADD/REMOVE t-Button--hot + SHOW/HIDE Body-*

## Seguranca
- p_protection_level: C
- p_autocomplete_on_off: OFF
- fn_page_is_readonly em toda pagina
- p_help_text: cod_telas:0;page_version: 1;

## Variaveis globais (sempre nas queries)
:G_COD_GRUPOEMPRESA, :G_COD_EMPRESA, :G_COD_FILIAL

## Botoes padrao
- FILTRAR: hot, css cs-flex-end, DEFINED_BY_DA
- BTN_PLANEJAR: hot, iconLeft fa-gear, NEXT
- BTN_IMPORTAR: iconLeft fa-file-pointer, NEXT
- ALTERAR: iconLeft fa-gear, COPY
- BTN_*: cs-Button--tabs + t-Button--gapLeft, PREVIOUS

## Alterar via collection
1. FOS.EXECUTE_PLSQL -> pr_create_collection('ALTERAR')
2. FOS.INTERACTIVE_GRID_PROCESS_ROWS -> CHECKED
3. NATIVE_EXECUTE_PLSQL -> pr_add_member(p_c001=>:ID1, p_c002=>:ID2...)
4. FOS.REDIRECT -> f?p=&APP_ID.:{DIALOG}:&SESSION...`;

function buildSystemPrompt(gl, page, schema, appId, group, enriched){
  enriched = enriched || { tables: [], pageSql: null };
  const compCtx = getCompContext();

  const allTables = [...(enriched.tables || [])];
  if (schCurrentTable && schColumns.length) {
    const already = allTables.find(t => t.table === schCurrentTable && t.owner === schCurrentOwner);
    if (!already) allTables.push({ owner: schCurrentOwner, table: schCurrentTable, columns: schColumns });
  }

  const tableCtx = allTables.length
    ? '\n\n' + allTables.map(t =>
        `ESTRUTURA REAL DE ${t.owner}.${t.table} (use exatamente estes nomes de coluna):\n` +
        t.columns.map(c => `  ${c.name.padEnd(32)} ${c.type}${c.nullable==='N'?' NOT NULL':''}`).join('\n')
      ).join('\n\n')
    : '';

  const pageSQL = enriched.pageSql || (document.getElementById('cfgPageSQL')?.value?.trim() || '');
  const isIncremental = genMode === 'incr' || (!!pageSQL && enriched.detectedPage);

  // -- MODO INCREMENTAL --
  if(isIncremental){
    return `Voce e um especialista em Oracle APEX 24.1 operando em MODO INCREMENTAL.
Sua funcao e adicionar ou modificar APENAS o componente solicitado em uma pagina ja existente.

REGRAS ABSOLUTAS:
1. NUNCA gerar wwv_flow_imp_page.remove_page
2. Gerar SOMENTE os componentes novos/modificados
3. Use wwv_flow_api (nao wwv_flow_imp_page) para incrementos

PADRAO OBRIGATORIO para botoes e itens incrementais:

DECLARE
  v_ws        NUMBER;
  v_base      NUMBER;
  v_region_id NUMBER;
  v_seq       NUMBER;
BEGIN
  SELECT workspace_id INTO v_ws FROM apex_applications WHERE application_id = ${appId};
  v_base := TO_NUMBER(TO_CHAR(SYSTIMESTAMP,'YYYYMMDDHH24MISSFF3'));

  -- buscar region_id da regiao alvo pelo static_id ou nome
  SELECT region_id INTO v_region_id
    FROM apex_application_page_regions
   WHERE application_id = ${appId}
     AND page_id = ${page}
     AND (static_id = '<STATIC_ID>' OR region_name = '<NOME_REGIAO>');

  -- sequencia: max da pagina + 10
  SELECT NVL(MAX(button_sequence), 10) + 10 INTO v_seq
    FROM apex_application_page_buttons
   WHERE application_id = ${appId} AND page_id = ${page};

  wwv_flow_api.set_security_group_id(v_ws);

  wwv_flow_api.create_page_button(
    p_id                      => v_base + 1,
    p_flow_id                 => ${appId},
    p_flow_step_id            => ${page},
    p_button_sequence         => v_seq,
    p_button_plug_id          => v_region_id,
    p_button_name             => 'NOME_BTN',
    p_button_static_id        => 'NOME_BTN',
    p_button_action           => 'DEFINED_BY_DA',
    p_button_template_id      => 10843798411754525354,
    p_button_template_options => '#DEFAULT#:t-Button--hot',
    p_button_is_hot           => 'Y',
    p_button_image_alt        => 'Label',
    p_button_position         => 'NEXT',
    p_button_css_classes      => 'cs-flex-end'
  );
  COMMIT;
END;
/

ERROS COMUNS - NUNCA FACA:
- NUNCA usar display_sequence (nao existe). Coluna correta: button_sequence
- NUNCA usar wwv_flow_imp.g_flow_id
- NUNCA usar wwv_flow_imp_page.create_page_button para incrementos
- NUNCA subquery direta dentro de parametro de funcao
- SEMPRE p_flow_id => ${appId} e p_flow_step_id => ${page} em todos componentes
${tableCtx}

GUIDELINE DO PROJETO:
${gl}
${compCtx}

CONFIGURACOES:
- Pagina: ${page}
- Schema: ${schema}
- App ID: ${appId}
- Grupo: ${group}
${pageSQL ? '\nSQL ATUAL DA PAGINA:\n' + pageSQL.slice(0, 6000) + (pageSQL.length > 6000 ? '\n-- [truncado]' : '') : ''}

FORMATO: 1-3 linhas explicando + bloco \`\`\`sql\`\`\`. Responda em portugues.`;
  }

  // -- MODO NOVA PAGINA --
  return `Voce e um especialista em Oracle APEX 24.1. Gere SQL de importacao de pagina APEX COMPLETO.

GUIDELINE DO PROJETO (seguir a risca):
${gl}
${compCtx}${tableCtx}

CONFIGURACOES:
- Pagina: ${page}
- Schema: ${schema}
- App ID: ${appId}
- Grupo: ${group}

REGRAS ABSOLUTAS DE GERACAO:
1. Sempre usar DECLARE v_ws NUMBER; v_base NUMBER; BEGIN ... END; /
   v_base := TO_NUMBER(TO_CHAR(SYSTIMESTAMP,'YYYYMMDDHH24MISSFF3'));
   Usar wwv_flow_api.set_security_group_id(v_ws) + wwv_flow_imp.import_begin + import_end
2. Sempre incluir: wwv_flow_imp_page.remove_page antes do create_page
3. p_protection_level sempre 'C'
4. p_autocomplete_on_off sempre 'OFF'
5. Todo IG: p_lazy_loading=true, p_javascript_code='setCustomConfig', p_stretch_columns=true
6. Todo LOV Enhanced: query com D e R nas primeiras posicoes, JSON sem D/R
7. Todo multifiltro: padrao case when nvl(:ITEM,'0')='0' then 1 when exists...
8. Variaveis globais em todas as queries: :G_COD_GRUPOEMPRESA, :G_COD_EMPRESA, :G_COD_FILIAL
9. Template IDs: declare variaveis e busque com SELECT INTO de apex_application_temp_*
10. Sempre fechar com: wwv_flow_imp.import_end(p_auto_install_sup_obj=>false); COMMIT; END; /

FORMATO: breve explicacao (1-3 linhas) + bloco SQL completo entre \`\`\`sql e \`\`\`. Responda em portugues.`;
}

function compactGuideline(gl){
  return String(gl || '')
    .split('\n')
    .filter(line => {
      const s = line.trim();
      if(!s) return false;
      return /^#|obrigat|sempre|nunca|IG|Interactive|Multifiltro|LOV|Seguran|Vari|Bot|Template|p_|- /.test(s);
    })
    .slice(0, 80)
    .join('\n');
}

function buildFastSystemPrompt(gl, page, schema, appId, group, enriched){
  enriched = enriched || { tables: [], pageSql: null };
  const tables = (enriched.tables || []).slice(0, 3);
  const tableCtx = tables.length
    ? '\n\nTABELAS DETECTADAS:\n' + tables.map(t =>
        `${t.owner}.${t.table}: ` + (t.columns || []).slice(0, 35).map(c => `${c.name} ${c.type}`).join(', ')
      ).join('\n')
    : '';
  const pageSQL = enriched.pageSql || (document.getElementById('cfgPageSQL')?.value?.trim() || '');
  const modeRules = genMode === 'incr'
    ? `MODO INCREMENTAL:
- NUNCA gerar remove_page ou create_page.
- Use wwv_flow_api (nao wwv_flow_imp_page) para botoes/itens/DAs incrementais.
- NUNCA usar display_sequence. Usar button_sequence de apex_application_page_buttons.
- region_id de apex_application_page_regions pode ser usado diretamente em wwv_flow_api.
- Sempre p_flow_id=>${appId} e p_flow_step_id=>${page} em todos componentes.
- Gere apenas os componentes pedidos. Copie padroes do SQL/CONTEXTO DA PAGINA.`
    : `MODO NOVA PAGINA:
- Gerar import APEX completo com wwv_flow_imp.import_begin/end.
- Use DECLARE v_ws/v_base e p_id => v_base+N.
- Inclua remove_page somente para pagina nova.
- Se houver SQL/CONTEXTO DA PAGINA, trate como REFERENCIA/MOLDE.`;

  return `Voce e especialista em Oracle APEX 24.1. Gere SQL APEX correto e curto.

CONFIG:
- Pagina: ${page}
- Schema: ${schema}
- App ID: ${appId}
- Grupo: ${group}

${modeRules}

REGRAS ESSENCIAIS:
- NUNCA usar subquery direta em parametro p_id/template/workspace.
- NUNCA usar wwv_flow_id.nextval ou wwv_flow_imp.g_flow_id.
- v_base := TO_NUMBER(TO_CHAR(SYSTIMESTAMP,'YYYYMMDDHH24MISSFF3'));
- Para incrementos: wwv_flow_api.set_security_group_id(v_ws) sem import_begin.
- Para pagina nova: import_begin(p_version_yyyy_mm_dd=>'2024.01.31',...) + import_end.
- p_protection_level => 'C' e p_autocomplete_on_off => 'OFF' quando criar pagina.
- IG: lazy_loading=true, setCustomConfig, stretch_columns=true.
- Responda em portugues com 1-3 linhas e bloco \`\`\`sql.

GUIDELINE RESUMIDA:
${compactGuideline(gl)}
${tableCtx}
${pageSQL ? '\nSQL/CONTEXTO DA PAGINA:\n' + pageSQL.slice(0, 2500) + (pageSQL.length > 2500 ? '\n-- [truncado]' : '') : ''}`;
}
