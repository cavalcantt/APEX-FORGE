@echo off
cd /d "%~dp0"
title APEX Forge - Servidor Local

echo.
echo  ==========================================
echo       APEX FORGE - Iniciando...
echo  ==========================================
echo.

if not exist ".env" (
    echo  [ERRO] Arquivo .env nao encontrado!
    echo  Verifique se o arquivo .env esta na mesma pasta.
    echo.
    pause
    exit /b 1
)

echo  Iniciando servidor na porta 3007...
echo  (Deixe esta janela aberta enquanto usar o Forge)
echo.

start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\server.ps1" -Port 3007

timeout /t 2 /nobreak >nul

echo  Abrindo APEX Forge no browser...
start "" "http://localhost:3007/"

echo.
echo  Servidor rodando em http://localhost:3007/
echo  Feche esta janela para encerrar.
pause
