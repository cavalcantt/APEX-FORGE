set echo off
set feedback off
set serveroutput on size unlimited
set pagesize 0
set linesize 32767

BEGIN
  FOR r IN (
    SELECT object_name, object_type
    FROM   all_objects
    WHERE  owner = 'AGRICOLA'
    AND    object_type IN ('TABLE', 'VIEW', 'TRIGGER', 'PACKAGE', 'PROCEDURE', 'FUNCTION')
    ORDER BY object_type, object_name
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.object_name || '|' || r.object_type);
  END LOOP;
END;
/
exit