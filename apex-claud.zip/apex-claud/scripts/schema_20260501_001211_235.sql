set markup csv on delimiter ',' quote on
set feedback off
set heading on
set pagesize 0
set linesize 32767

SELECT table_name FROM all_tables WHERE owner = 'AGRICOLA' ORDER BY table_name

exit