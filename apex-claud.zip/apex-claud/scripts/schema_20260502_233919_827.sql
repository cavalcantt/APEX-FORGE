set echo off
set feedback off
set serveroutput on size unlimited
set pagesize 0
set linesize 32767

BEGIN
  FOR r IN (
    SELECT object_name as table_name
    FROM   all_objects
    WHERE  owner = 'AGRICOLA'
    AND    object_type IN ('TABLE', 'VIEW')
    ORDER BY object_name
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.table_name);
  END LOOP;
END;
/
exit