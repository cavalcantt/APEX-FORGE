set echo off
set feedback off
set serveroutput on size unlimited
set pagesize 0
set linesize 32767

BEGIN
  FOR r IN (
    SELECT table_name
    FROM   all_tables
    WHERE  owner = 'AGRICOLA'
    ORDER BY table_name
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.table_name);
  END LOOP;
END;
/
exit