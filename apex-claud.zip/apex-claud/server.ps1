# ===============================================================
# APEX FORGE - Servidor HTTP Local (PowerShell)
# Porta: 3007
# ===============================================================

param(
    [int]$Port = 3007,
    [string]$ConfigFile = ".\.env"
)

$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Log {
    param([string]$Msg, [string]$Level = "Info")
    $timestamp = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "Success" { "Green" }
        "Error"   { "Red" }
        "Warning" { "Yellow" }
        default   { "Cyan" }
    }
    $icon = switch ($Level) {
        "Success" { "[OK]"   }
        "Error"   { "[ERR]"  }
        "Warning" { "[WARN]" }
        default   { "[INFO]" }
    }
    Write-Host "[$timestamp] $icon $Msg" -ForegroundColor $color
}

function Load-Env {
    $envPath = Join-Path $ScriptDir $ConfigFile
    if (-not (Test-Path $envPath)) {
        Write-Log "Arquivo .env nao encontrado em: $envPath" "Error"
        exit 1
    }
    $config = @{}
    Get-Content $envPath | Where-Object { $_ -and -not $_.StartsWith("#") } | ForEach-Object {
        if ($_ -match "^([^=]+)=(.*)$") {
            $config[$Matches[1].Trim()] = $Matches[2].Trim()
        }
    }
    return $config
}

function Set-SqlclEnv {
    param([System.Diagnostics.ProcessStartInfo]$Psi, [hashtable]$Config)
    $nlsLang = if ($Config.NLS_LANG) { $Config.NLS_LANG } else { "AMERICAN_AMERICA.AL32UTF8" }
    $Psi.EnvironmentVariables["NLS_LANG"] = $nlsLang
    $Psi.EnvironmentVariables["JAVA_TOOL_OPTIONS"] = "-Dfile.encoding=UTF-8"
}

function Read-JsonBody {
    param([System.Net.HttpListenerRequest]$Request)

    $reader = New-Object System.IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    try {
        $body = $reader.ReadToEnd()
        if (-not $body) { return $null }
        return ($body | ConvertFrom-Json)
    } finally {
        $reader.Close()
    }
}

function Test-LocalOrigin {
    param([System.Net.HttpListenerRequest]$Request)

    $origin = $Request.Headers["Origin"]
    if (-not $origin -or $origin -eq "null") { return $true }

    try {
        $uri = [Uri]$origin
        return $uri.Host -in @("localhost", "127.0.0.1", "::1")
    } catch {
        return $false
    }
}

function Test-ForgeToken {
    param([System.Net.HttpListenerRequest]$Request)

    $config = Load-Env
    $token = $config.FORGE_TOKEN
    if (-not $token) { return $true }

    $provided = $Request.Headers["X-Forge-Token"]
    return $provided -and ($provided -eq $token)
}

function Test-RequestAllowed {
    param([System.Net.HttpListenerRequest]$Request)

    if (-not (Test-LocalOrigin -Request $Request)) {
        return @{ ok = $false; error = "Origem nao permitida. Use o Forge localmente." }
    }
    if (-not (Test-ForgeToken -Request $Request)) {
        return @{ ok = $false; error = "Token local invalido. Defina FORGE_TOKEN no .env e envie X-Forge-Token." }
    }
    return @{ ok = $true }
}

function Test-ApexImportSql {
    param([string]$Sql)

    $issues = @()
    $warnings = @()
    $s = $Sql.Trim()
    $sl = $s.ToLower()

    # Detecta tipo de SQL — PL/SQL direto (DECLARE/BEGIN) nao precisa de wrapper APEX
    $isPlSql = $sl -match '(?m)^\s*(declare|begin)\b'
    $isApexExport = $sl -match 'wwv_flow_imp\.import_begin'

    if ($isApexExport) {
        # Valida estrutura completa de exportacao APEX
        if ($s -notmatch '(?is)\bwwv_flow_imp\.import_begin\s*\(') { $issues += "SQL nao contem wwv_flow_imp.import_begin." }
        if ($s -notmatch '(?is)\bwwv_flow_imp\.import_end\s*\(') { $issues += "SQL nao contem wwv_flow_imp.import_end." }
        if ($s -notmatch '(?is)\bwwv_flow_imp_page\.remove_page\s*\(') { $warnings += "SQL nao remove a pagina antes de criar. Verifique se isso e intencional." }
        if ($s -notmatch '(?is)\bcommit\s*;') { $warnings += "SQL nao contem commit explicito." }
        if ($s -notmatch '(?is)\bp_protection_level\s*=>\s*''C''') { $warnings += "p_protection_level=>'C' nao encontrado." }
        if ($s -notmatch '(?is)\bp_autocomplete_on_off\s*=>\s*''OFF''') { $warnings += "p_autocomplete_on_off=>'OFF' nao encontrado." }
    }
    # PL/SQL direto (DECLARE/BEGIN): aceita sem validacao de estrutura APEX

    # Comandos destrutivos — bloqueados em qualquer tipo
    $danger = @(
        '(?is)\bdrop\s+(table|user|schema|database)\b',
        '(?is)\btruncate\s+table\b',
        '(?is)\bdelete\s+from\s+(?!wwv_flow|apex_)',
        '(?is)\bupdate\s+(?!wwv_flow|apex_)',
        '(?is)\bexecute\s+immediate\b'
    )
    foreach ($pattern in $danger) {
        if ($s -match $pattern) {
            $issues += "Comando potencialmente perigoso detectado: $($Matches[0])"
        }
    }

    return @{
        valid = ($issues.Count -eq 0)
        issues = $issues
        warnings = $warnings
        type = if ($isApexExport) { "apex_export" } elseif ($isPlSql) { "plsql" } else { "dml" }
    }
}


function Invoke-SQL {
    param([string]$Sql, [bool]$ValidateApex = $false)

    $config = Load-Env

    foreach ($key in @("DB_CONNECTION", "SQLCL_PATH")) {
        if (-not $config[$key]) {
            return @{ success = $false; error = "Variavel '$key' nao encontrada no .env" }
        }
    }

    if ($ValidateApex) {
        $validation = Test-ApexImportSql -Sql $Sql
        if (-not $validation.valid) {
            return @{
                success = $false
                error = "Validacao bloqueou a execucao."
                validation = $validation
            }
        }
    }

    if (-not (Test-Path $config.SQLCL_PATH)) {
        return @{ success = $false; error = "SQLcl nao encontrado em: $($config.SQLCL_PATH)" }
    }

    $scriptsDir = Join-Path $ScriptDir "scripts"
    if (-not (Test-Path $scriptsDir)) {
        New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
    }

    $stamp    = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $tempFile = Join-Path $scriptsDir "forge_temp_$stamp.sql"
    $outFile  = "$tempFile.out"
    $errFile  = "$tempFile.err"

    try {
        $Sql = $Sql.TrimStart([char]0xFEFF, [char]0x200B)

        # Remove barra final duplicada
        $sqlTrimmed = $Sql.TrimEnd()
        if ($sqlTrimmed.EndsWith('/')) {
            $Sql = $sqlTrimmed.Substring(0, $sqlTrimmed.Length - 1).TrimEnd()
        }

        # Adiciona COMMIT automatico para PL/SQL direto sem commit
        $isPlSql2 = $Sql -match '(?im)^\s*(declare|begin)\b'
        $hasCommit2 = $Sql -match '(?i)\bcommit\s*;'
        if ($isPlSql2 -and -not $hasCommit2) {
            Write-Log "PL/SQL sem COMMIT: adicionando COMMIT automatico." "Warning"
            $Sql = $Sql + "`r`nCOMMIT;"
        }

        $fullSql = [string]::Join("`r`n", @("set echo on", "set feedback on", "set pagesize 50000", "set linesize 32767", "", $Sql, "/", "exit"))
        $enc = New-Object System.Text.UTF8Encoding $false
        [System.IO.File]::WriteAllText($tempFile, $fullSql, $enc)

        $driver     = if ($config.DB_DRIVER) { $config.DB_DRIVER.ToLower() } else { "thin" }
        $driverFlag = if ($driver -eq "thin") { "-thin" } else { $null }
        $timeoutSec = if ($config.TIMEOUT)    { [int]$config.TIMEOUT }       else { 90 }

        # -S = silent mode: desabilita deteccao de TTY e prompt interativo
        # sem esse flag o sql.exe trava dentro do HttpListener (sem console)
        $argList = @("-S")
        if ($driverFlag) { $argList += $driverFlag }
        $argList += $config.DB_CONNECTION
        $argList += "@`"$tempFile`""

        Write-Log "Executando SQLcl -S: $($argList -join ' ')" "Info"

        $startTime = Get-Date

        # ProcessStartInfo com BaseStream.Close() — unica forma confiavel de
        # fechar stdin dentro do HttpListener sem travar o SQLcl
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName               = $config.SQLCL_PATH
        $psi.Arguments              = $argList -join ' '
        $psi.UseShellExecute        = $false
        $psi.CreateNoWindow         = $true
        $psi.RedirectStandardInput  = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8
        Set-SqlclEnv -Psi $psi -Config $config

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null
        $proc.StandardInput.BaseStream.Close()

        $finished = $proc.WaitForExit($timeoutSec * 1000)

        if (-not $finished) {
            $proc.Kill()
            $duration = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 2)
            Write-Log "SQLcl encerrado por timeout (${timeoutSec}s)" "Error"
            return @{ success = $false; error = "Timeout apos ${timeoutSec}s. Banco inacessivel ou SQL muito lento."; duration = $duration }
        }

        $duration   = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 2)
        $outText    = $proc.StandardOutput.ReadToEnd()
        $errText    = $proc.StandardError.ReadToEnd()
        $outputText = ($outText + "`n" + $errText).Trim()
        $exitCode   = $proc.ExitCode
        $success    = $exitCode -eq 0 -or $outputText -match '(?im)procedimento pl/sql conclu[ií]do com sucesso'

        Write-Log "Concluido em ${duration}s - Exit: $exitCode" $(if ($success) { "Success" } else { "Error" })

        $errorMessage = if ($success) {
            $null
        } elseif ($errText.Trim()) {
            $errText.Trim()
        } elseif ($outputText.Trim()) {
            ($outputText.Trim() -split "`n")[0]
        } else {
            "SQLcl retornou codigo $exitCode"
        }

        return @{
            success  = $success
            output   = $outputText
            error    = $errorMessage
            duration = $duration
            file     = (Split-Path $tempFile -Leaf)
        }

    } catch {
        Write-Log "Erro ao executar SQLcl: $_" "Error"
        return @{ success = $false; error = $_.Exception.Message }
    } finally {
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-SchemaQuery {
    # Executa um bloco PL/SQL que imprime linhas via DBMS_OUTPUT e retorna o texto.
    # O caller monta o bloco PL/SQL completo (BEGIN...END) e o passa em $PlSql.
    param([string]$PlSql)

    $config = Load-Env

    foreach ($key in @("DB_CONNECTION", "SQLCL_PATH")) {
        if (-not $config[$key]) {
            return @{ success = $false; error = "Variavel '$key' nao encontrada no .env" }
        }
    }

    if (-not (Test-Path $config.SQLCL_PATH)) {
        return @{ success = $false; error = "SQLcl nao encontrado em: $($config.SQLCL_PATH)" }
    }

    $scriptsDir = Join-Path $ScriptDir "scripts"
    if (-not (Test-Path $scriptsDir)) {
        New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
    }

    $stamp    = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $tempFile = Join-Path $scriptsDir "schema_$stamp.sql"

    try {
        $fullSql = @"
set echo off
set feedback off
set serveroutput on size unlimited
set pagesize 0
set linesize 32767

$PlSql
/
exit
"@
        $enc = New-Object System.Text.UTF8Encoding $false
        [System.IO.File]::WriteAllText($tempFile, $fullSql, $enc)

        $driver     = if ($config.DB_DRIVER) { $config.DB_DRIVER.ToLower() } else { "thin" }
        $driverFlag = if ($driver -eq "thin") { "-thin" } else { $null }
        $timeoutSec = if ($config.TIMEOUT)    { [int]$config.TIMEOUT }       else { 120 }

        $argList = @("-S")
        if ($driverFlag) { $argList += $driverFlag }
        $argList += $config.DB_CONNECTION
        $argList += "@`"$tempFile`""

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName               = $config.SQLCL_PATH
        $psi.Arguments              = $argList -join ' '
        $psi.UseShellExecute        = $false
        $psi.CreateNoWindow         = $true
        $psi.RedirectStandardInput  = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8
        Set-SqlclEnv -Psi $psi -Config $config

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null
        $proc.StandardInput.BaseStream.Close()

        $startTime = Get-Date
        $finished  = $proc.WaitForExit($timeoutSec * 1000)

        if (-not $finished) {
            $proc.Kill()
            $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)
            return @{ success = $false; error = "Timeout apos ${elapsed}s (limite ${timeoutSec}s). Banco inacessivel ou consulta muito lenta." }
        }

        $outText = $proc.StandardOutput.ReadToEnd().Trim()
        $errText = $proc.StandardError.ReadToEnd().Trim()

        # Ignora a mensagem de conclusao PL/SQL, que nao e erro
        $isMsgOnly = $outText -match '(?i)procedimento pl/sql conclu'
        if ($proc.ExitCode -ne 0 -and $errText -and (-not $outText -or $isMsgOnly)) {
            return @{ success = $false; error = $errText }
        }
        if ($outText -match '(?i)(ORA-\d+|PLS-\d+)') {
            return @{ success = $false; error = $outText }
        }

        # Remove a linha de conclusao PL/SQL da saida util
        $cleanOut = ($outText -split "`n") |
                    Where-Object { $_ -notmatch '(?i)procedimento pl/sql conclu|pl/sql procedure successfully|JAVA_TOOL_OPTIONS' } |
                    ForEach-Object { $_.Trim() } |
                    Where-Object { $_ -ne '' }

        return @{ success = $true; lines = $cleanOut }
    } catch {
        return @{ success = $false; error = $_.Exception.Message }
    } finally {
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-OpenAI {
    param([string]$System, [string]$UserMsg, [string]$Model, [string]$ApiKey, [int]$TimeoutSec = 180)

    $config = Load-Env
    if (-not $ApiKey) { $ApiKey = $config.OPENAI_API_KEY }
    if (-not $ApiKey) { return @{ success = $false; error = "OPENAI_API_KEY nao definido no .env" } }
    if (-not $Model) { $Model = "gpt-4.1" }

    try {
        $body = @{
            model = $Model
            messages = @(
                @{ role = "system"; content = $System },
                @{ role = "user"; content = $UserMsg }
            )
            max_tokens = 8000
            temperature = 0.2
        } | ConvertTo-Json -Depth 10

        $headers = @{
            "Authorization" = "Bearer $ApiKey"
            "Content-Type" = "application/json"
        }

        $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $res = Invoke-RestMethod -Uri "https://api.openai.com/v1/chat/completions" -Method Post -Headers $headers -Body $bodyBytes -ContentType "application/json; charset=utf-8" -TimeoutSec $TimeoutSec
        $text = $res.choices[0].message.content
        return @{ success = $true; text = $text }
    } catch {
        return @{ success = $false; error = $_.Exception.Message }
    }
}

function Invoke-Anthropic {
    param([string]$System, [string]$UserMsg, [string]$Model, [string]$ApiKey, [int]$TimeoutSec = 180)

    $config = Load-Env
    if (-not $ApiKey) { $ApiKey = $config.ANTHROPIC_API_KEY }
    if (-not $ApiKey) { return @{ success = $false; error = "ANTHROPIC_API_KEY nao definido no .env" } }
    if (-not $Model) { $Model = "claude-sonnet-4-20250514" }

    try {
        $body = @{
            model = $Model
            max_tokens = 8000
            system = $System
            messages = @(@{ role = "user"; content = $UserMsg })
        } | ConvertTo-Json -Depth 10

        $headers = @{
            "x-api-key" = $ApiKey
            "anthropic-version" = "2023-06-01"
            "Content-Type" = "application/json"
        }

        $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $res = Invoke-RestMethod -Uri "https://api.anthropic.com/v1/messages" -Method Post -Headers $headers -Body $bodyBytes -ContentType "application/json; charset=utf-8" -TimeoutSec $TimeoutSec
        $text = ($res.content | Where-Object { $_.type -eq "text" } | Select-Object -First 1).text
        return @{ success = $true; text = $text }
    } catch {
        return @{ success = $false; error = $_.Exception.Message }
    }
}


function Invoke-ClaudeCode {
    param([string]$System, [string]$UserMsg, [int]$TimeoutSec = 180, [System.Net.HttpListenerResponse]$Response = $null)

    $scriptsDir = Join-Path $ScriptDir "scripts"
    if (-not (Test-Path $scriptsDir)) {
        New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
    }

    $claudeCmd = (Get-Command "claude" -ErrorAction SilentlyContinue)
    if (-not $claudeCmd) {
        return @{ success = $false; error = "claude CLI nao encontrado no PATH. Verifique a instalacao do Claude Code." }
    }

    try {
        $fullPrompt = "$System`n`n---`n`nMENSAGEM DO USUARIO:`n$UserMsg"

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName               = $claudeCmd.Source
        $psi.Arguments              = "-p --output-format text"
        $psi.UseShellExecute        = $false
        $psi.CreateNoWindow         = $true
        $psi.RedirectStandardInput  = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null

        $inputBytes = [System.Text.Encoding]::UTF8.GetBytes($fullPrompt)
        $proc.StandardInput.BaseStream.Write($inputBytes, 0, $inputBytes.Length)
        $proc.StandardInput.BaseStream.Close()

        if ($Response) {
            $Response.StatusCode = 200
            $Response.ContentType = "text/event-stream"
            $Response.Headers.Add("Access-Control-Allow-Origin", "*")
            $Response.Headers.Add("Cache-Control", "no-cache")
            $Response.SendChunked = $true

            $buffer = New-Object char[] 128
            $reader = $proc.StandardOutput
            
            while (($bytesRead = $reader.Read($buffer, 0, $buffer.Length)) -gt 0) {
                $text = new-object string($buffer, 0, $bytesRead)
                $jsonChunk = @{ chunk = $text } | ConvertTo-Json -Compress
                $chunkStr = "data: $jsonChunk`n`n"
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($chunkStr)
                $Response.OutputStream.Write($bytes, 0, $bytes.Length)
                $Response.OutputStream.Flush()
            }
            
            $finished = $proc.WaitForExit($TimeoutSec * 1000)
            if (-not $finished) { $proc.Kill() }
            
            # Send end marker
            $endBytes = [System.Text.Encoding]::UTF8.GetBytes("data: [DONE]`n`n")
            $Response.OutputStream.Write($endBytes, 0, $endBytes.Length)
            $Response.OutputStream.Flush()
            $Response.OutputStream.Close()
            
            Write-Log "Claude stream concluido." "Success"
            return @{ success = $true; streamed = $true }
        }

        # Fallback (non-streaming)
        $finished = $proc.WaitForExit($TimeoutSec * 1000)

        if (-not $finished) {
            $proc.Kill()
            return @{ success = $false; error = "Timeout apos ${TimeoutSec}s" }
        }

        $outText = $proc.StandardOutput.ReadToEnd().Trim()
        $errText = $proc.StandardError.ReadToEnd().Trim()

        if ($proc.ExitCode -eq 0 -and $outText) {
            Write-Log "Claude respondeu: $($outText.Length) chars" "Success"
            return @{ success = $true; text = $outText }
        } else {
            $msg = if ($errText) { $errText } elseif ($outText) { $outText } else { "claude retornou vazio (exit $($proc.ExitCode))" }
            Write-Log "Claude retornou erro (exit $($proc.ExitCode)): $msg" "Error"
            return @{ success = $false; error = $msg; exitCode = $proc.ExitCode }
        }
    } catch {
        Write-Log "Erro Invoke-ClaudeCode: $_" "Error"
        return @{ success = $false; error = $_.Exception.Message }
    }
}

function Invoke-CodexCli {
    param([string]$System, [string]$UserMsg, [int]$TimeoutSec = 180)

    $config = Load-Env
    $codexCmd = if ($config.CODEX_CLI_PATH -and (Test-Path $config.CODEX_CLI_PATH)) {
        @{ Source = $config.CODEX_CLI_PATH }
    } else {
        $cmd = Get-Command "codex.cmd" -ErrorAction SilentlyContinue
        if (-not $cmd) { $cmd = Get-Command "codex.exe" -ErrorAction SilentlyContinue }
        if (-not $cmd) { $cmd = Get-Command "codex" -ErrorAction SilentlyContinue }
        $cmd
    }

    if (-not $codexCmd) {
        return @{ success = $false; error = "codex CLI nao encontrado no PATH. Instale ou rode codex --login." }
    }

    $argString = if ($config.CODEX_CLI_ARGS) { $config.CODEX_CLI_ARGS } else { "--ask-for-approval never exec --skip-git-repo-check -" }

    try {
        $fullPrompt = "$System`n`n---`n`nMENSAGEM DO USUARIO:`n$UserMsg"

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        if ($codexCmd.Source -like "*.cmd") {
            $psi.FileName           = "cmd.exe"
            $psi.Arguments          = "/c `"$($codexCmd.Source)`" $argString"
        } else {
            $psi.FileName           = $codexCmd.Source
            $psi.Arguments          = $argString
        }
        $psi.WorkingDirectory       = $ScriptDir
        $psi.UseShellExecute        = $false
        $psi.CreateNoWindow         = $true
        $psi.RedirectStandardInput  = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null
        $outTask = $proc.StandardOutput.ReadToEndAsync()
        $errTask = $proc.StandardError.ReadToEndAsync()
        $promptBytes = [System.Text.Encoding]::UTF8.GetBytes($fullPrompt)
        $proc.StandardInput.BaseStream.Write($promptBytes, 0, $promptBytes.Length)
        $proc.StandardInput.BaseStream.Close()

        $finished = $proc.WaitForExit($TimeoutSec * 1000)
        if (-not $finished) {
            $proc.Kill()
            return @{ success = $false; error = "Timeout apos ${TimeoutSec}s" }
        }

        $outText = $outTask.Result.Trim()
        $errText = $errTask.Result.Trim()

        if ($proc.ExitCode -eq 0 -and $outText) {
            Write-Log "Codex respondeu: $($outText.Length) chars" "Success"
            return @{ success = $true; text = $outText }
        }

        $msg = if ($errText) { $errText } elseif ($outText) { $outText } else { "codex retornou vazio (exit $($proc.ExitCode))" }
        Write-Log "Codex retornou erro (exit $($proc.ExitCode)): $msg" "Error"
        return @{ success = $false; error = $msg; exitCode = $proc.ExitCode; args = $argString }
    } catch {
        Write-Log "Erro Invoke-CodexCli: $_" "Error"
        return @{ success = $false; error = $_.Exception.Message; args = $argString }
    }
}

function Send-Response {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [object]$Body,
        [int]$StatusCode = 200
    )
    $json  = $Body | ConvertTo-Json -Depth 5 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $Response.StatusCode    = $StatusCode
    $Response.ContentType   = "application/json; charset=utf-8"
    $Response.Headers.Add("Access-Control-Allow-Origin",  "*")
    $Response.Headers.Add("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
    $Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.OutputStream.Close()
}

# ---------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------
Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Magenta
Write-Host "       APEX FORGE - Servidor Local"          -ForegroundColor Magenta
Write-Host "  ==========================================" -ForegroundColor Magenta
Write-Host ""
Write-Log "Iniciando na porta $Port..." "Info"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")

try {
    $listener.Start()
} catch {
    Write-Log "Erro ao iniciar: $_" "Error"
    Write-Log "Rode como Administrador ou verifique se porta $Port esta ocupada." "Warning"
    Read-Host "Pressione Enter para fechar"
    exit 1
}

Write-Log "Servidor rodando em http://localhost:$Port" "Success"
Write-Log "Pressione Ctrl+C para parar" "Warning"
Write-Host ""

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $req     = $context.Request
        $resp    = $context.Response
        $method  = $req.HttpMethod
        $path    = $req.Url.AbsolutePath

        Write-Log "$method $path" "Info"

        if ($method -eq "OPTIONS") {
            Send-Response $resp @{ ok = $true }
            continue
        }

        if ($path -eq "/health" -and $method -eq "GET") {
            Send-Response $resp @{ status = "ok"; server = "APEX Forge PowerShell"; port = $Port }
            continue
        }

        if ($path -eq "/codex-health" -and $method -eq "GET") {
            $config = Load-Env
            $cmd = if ($config.CODEX_CLI_PATH -and (Test-Path $config.CODEX_CLI_PATH)) {
                $config.CODEX_CLI_PATH
            } else {
                $found = Get-Command "codex.cmd" -ErrorAction SilentlyContinue
                if (-not $found) { $found = Get-Command "codex.exe" -ErrorAction SilentlyContinue }
                if (-not $found) { $found = Get-Command "codex" -ErrorAction SilentlyContinue }
                $found.Source
            }
            Send-Response $resp @{ success = [bool]$cmd; path = $cmd; args = $(if ($config.CODEX_CLI_ARGS) { $config.CODEX_CLI_ARGS } else { "exec --skip-git-repo-check -" }) }
            continue
        }

        if ($path -eq "/execute-sqlcl" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                $sql  = $data.sql

                if (-not $sql) {
                    Send-Response $resp @{ success = $false; error = "Campo sql nao encontrado no body" } 400
                    continue
                }

                $lineCount = ($sql -split "`n").Count
                Write-Log "SQL recebido: $lineCount linhas" "Info"
                $validateApex = if ($null -ne $data.validateApex) { [bool]$data.validateApex } else { $false }
                $result = Invoke-SQL -Sql $sql -ValidateApex $validateApex
                Send-Response $resp $result

            } catch {
                Write-Log "Erro ao processar request: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/validate-sql" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                $sql  = $data.sql
                if (-not $sql) {
                    Send-Response $resp @{ success = $false; error = "Campo sql nao encontrado no body" } 400
                    continue
                }

                $validation = Test-ApexImportSql -Sql $sql
                Send-Response $resp @{ success = $true; validation = $validation }
            } catch {
                Write-Log "Erro /validate-sql: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/ai-claude" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req

                if (-not $data.message) {
                    Send-Response $resp @{ success = $false; error = "Campo 'message' obrigatorio" } 400
                    continue
                }

                $sys     = if ($data.system)  { $data.system }  else { "" }
                $timeout = if ($data.timeout) { [int]$data.timeout } else { 180 }

                Write-Log "Claude Code gerando resposta..." "Info"
                $result = Invoke-ClaudeCode -System $sys -UserMsg $data.message -TimeoutSec $timeout -Response $resp
                if (-not $result.streamed) {
                    Send-Response $resp $result
                }
            } catch {
                Write-Log "Erro /ai-claude: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/ai-codex" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                if (-not $data.message) {
                    Send-Response $resp @{ success = $false; error = "Campo 'message' obrigatorio" } 400
                    continue
                }

                $timeout = if ($data.timeout) { [int]$data.timeout } else { 180 }
                Write-Log "Codex CLI gerando resposta..." "Info"
                $result = Invoke-CodexCli -System $data.system -UserMsg $data.message -TimeoutSec $timeout
                Send-Response $resp $result
            } catch {
                Write-Log "Erro /ai-codex: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/ai-openai" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                if (-not $data.message) {
                    Send-Response $resp @{ success = $false; error = "Campo 'message' obrigatorio" } 400
                    continue
                }

                Write-Log "OpenAI gerando resposta..." "Info"
                $result = Invoke-OpenAI -System $data.system -UserMsg $data.message -Model $data.model -ApiKey $data.apiKey -TimeoutSec $(if ($data.timeout) { [int]$data.timeout } else { 180 })
                Send-Response $resp $result
            } catch {
                Write-Log "Erro /ai-openai: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/ai-anthropic" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                if (-not $data.message) {
                    Send-Response $resp @{ success = $false; error = "Campo 'message' obrigatorio" } 400
                    continue
                }

                Write-Log "Anthropic gerando resposta..." "Info"
                $result = Invoke-Anthropic -System $data.system -UserMsg $data.message -Model $data.model -ApiKey $data.apiKey -TimeoutSec $(if ($data.timeout) { [int]$data.timeout } else { 180 })
                Send-Response $resp $result
            } catch {
                Write-Log "Erro /ai-anthropic: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }
        if ($path -eq "/fetch-apex-page" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data   = Read-JsonBody -Request $req
                $appId  = [int]($data.appId)
                $pageId = [int]($data.pageId)

                if ($appId -le 0 -or $pageId -le 0) {
                    Send-Response $resp @{ success = $false; error = "appId e pageId devem ser numeros positivos" } 400
                    continue
                }

                $config = Load-Env
                foreach ($key in @("DB_CONNECTION", "SQLCL_PATH")) {
                    if (-not $config[$key]) {
                        Send-Response $resp @{ success = $false; error = "Variavel '$key' nao encontrada no .env" }
                        continue
                    }
                }

                Write-Log "Fetching APEX page: app=$appId page=$pageId" "Info"

                $scriptsDir = Join-Path $ScriptDir "scripts"
                if (-not (Test-Path $scriptsDir)) {
                    New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
                }

                $stamp    = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
                $tempFile = Join-Path $scriptsDir "apexpage_$stamp.sql"

                $fetchSql = @"
set long 1000000
set longchunksize 32767
set pagesize 0
set feedback off
set heading off
set linesize 32767
set trimout on
set trimspool on

SELECT column_value
FROM   TABLE(APEX_EXPORT.GET_PAGE(
         p_application_id => $appId,
         p_page_id        => $pageId
       ));

exit
"@
                $enc = New-Object System.Text.UTF8Encoding $false
                [System.IO.File]::WriteAllText($tempFile, $fetchSql, $enc)

                $driver     = if ($config.DB_DRIVER) { $config.DB_DRIVER.ToLower() } else { "thin" }
                $driverFlag = if ($driver -eq "thin") { "-thin" } else { $null }

                $argList = @("-S")
                if ($driverFlag) { $argList += $driverFlag }
                $argList += $config.DB_CONNECTION
                $argList += "@`"$tempFile`""

                $psi = New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName               = $config.SQLCL_PATH
                $psi.Arguments              = $argList -join ' '
                $psi.UseShellExecute        = $false
                $psi.CreateNoWindow         = $true
                $psi.RedirectStandardInput  = $true
                $psi.RedirectStandardOutput = $true
                $psi.RedirectStandardError  = $true
                Set-SqlclEnv -Psi $psi -Config $config

                $proc = New-Object System.Diagnostics.Process
                $proc.StartInfo = $psi
                $proc.Start() | Out-Null
                $proc.StandardInput.BaseStream.Close()

                $finished = $proc.WaitForExit(60 * 1000)

                if (-not $finished) {
                    $proc.Kill()
                    Send-Response $resp @{ success = $false; error = "Timeout ao exportar pagina APEX (60s)" }
                    continue
                }

                $outText = $proc.StandardOutput.ReadToEnd().Trim()
                $errText = $proc.StandardError.ReadToEnd().Trim()

                # APEX_EXPORT.GET_PAGE pode nao existir em versoes antigas — fallback para summary
                if ($proc.ExitCode -ne 0 -or $outText -match 'SP2-|ORA-|PLS-' -or $outText.Length -lt 50) {
                    Write-Log "APEX_EXPORT falhou (exit $($proc.ExitCode)). Tentando summary via dicionario..." "Warning"
                    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue

                    $summarySql = @"
set feedback off
set heading off
set pagesize 0
set linesize 32767
set colsep '|'
set trimout on

-- Pagina
SELECT 'PAGE|' || TO_CHAR(page_id) || '|' || page_name || '|'
FROM   apex_application_pages
WHERE  application_id = $appId AND page_id = $pageId;

-- Regioes
SELECT 'REGION|' || TO_CHAR(region_id) || '|' || region_name || '|' || source_type
FROM   apex_application_page_regions
WHERE  application_id = $appId AND page_id = $pageId
ORDER BY source_type;

-- Items
SELECT 'ITEM|' || item_name || '|' || display_as_code || '|' || NVL(region, '')
FROM   apex_application_page_items
WHERE  application_id = $appId AND page_id = $pageId;

-- Botoes
SELECT 'BUTTON|' || button_name || '|' || button_action || '|' || NVL(region, '')
FROM   apex_application_page_buttons
WHERE  application_id = $appId AND page_id = $pageId;

exit
"@
                    $stamp2    = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
                    $tempFile2 = Join-Path $scriptsDir "apexsummary_$stamp2.sql"
                    [System.IO.File]::WriteAllText($tempFile2, $summarySql, $enc)

                    $argList2 = @("-S")
                    if ($driverFlag) { $argList2 += $driverFlag }
                    $argList2 += $config.DB_CONNECTION
                    $argList2 += "@`"$tempFile2`""

                    $psi2 = New-Object System.Diagnostics.ProcessStartInfo
                    $psi2.FileName               = $config.SQLCL_PATH
                    $psi2.Arguments              = $argList2 -join ' '
                    $psi2.UseShellExecute        = $false
                    $psi2.CreateNoWindow         = $true
                    $psi2.RedirectStandardInput  = $true
                    $psi2.RedirectStandardOutput = $true
                    $psi2.RedirectStandardError  = $true
                    Set-SqlclEnv -Psi $psi2 -Config $config

                    $proc2 = New-Object System.Diagnostics.Process
                    $proc2.StartInfo = $psi2
                    $proc2.Start() | Out-Null
                    $proc2.StandardInput.BaseStream.Close()
                    $proc2.WaitForExit(30 * 1000) | Out-Null

                    $summaryOut = $proc2.StandardOutput.ReadToEnd().Trim()
                    Remove-Item $tempFile2 -Force -ErrorAction SilentlyContinue

                    if ($summaryOut.Length -gt 10) {
                        Send-Response $resp @{
                            success = $true
                            mode    = "summary"
                            appId   = $appId
                            pageId  = $pageId
                            sql     = "-- Resumo da pagina App $appId, Pagina $pageId (via dicionario APEX)`n-- Use este contexto para incrementar a pagina.`n`n$summaryOut"
                        }
                    } else {
                        Send-Response $resp @{ success = $false; error = "Nao foi possivel exportar a pagina. Verifique permissoes (APEX_EXPORT ou dicionario APEX)." }
                    }
                    continue
                }

                Write-Log "Pagina APEX exportada: $($outText.Length) chars" "Success"
                Send-Response $resp @{
                    success = $true
                    mode    = "export"
                    appId   = $appId
                    pageId  = $pageId
                    sql     = $outText
                }

            } catch {
                Write-Log "Erro /fetch-apex-page: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            } finally {
                Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
            }
            continue
        }

        if ($path -eq "/schema-tables" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data  = Read-JsonBody -Request $req
                $owner = $data.owner
                if (-not $owner) {
                    Send-Response $resp @{ success = $false; error = "Campo 'owner' obrigatorio" } 400
                    continue
                }

                $owner = ($owner -replace '[^A-Za-z0-9_]', '').ToUpper()
                if (-not $owner) {
                    Send-Response $resp @{ success = $false; error = "Owner invalido" } 400
                    continue
                }

                Write-Log "Schema tables: owner=$owner" "Info"

                $plsql = @"
BEGIN
  FOR r IN (
    SELECT object_name, object_type
    FROM   all_objects
    WHERE  owner = '$owner'
    AND    object_type IN ('TABLE', 'VIEW', 'TRIGGER', 'PACKAGE', 'PROCEDURE', 'FUNCTION')
    ORDER BY object_type, object_name
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.object_name || '|' || r.object_type);
  END LOOP;
END;
"@
                $result = Invoke-SchemaQuery -PlSql $plsql

                if (-not $result.success) {
                    Send-Response $resp @{ success = $false; error = $result.error }
                    continue
                }

                $objs = @()
                $result.lines | Where-Object { $_.Trim() -ne '' } | ForEach-Object {
                    $parts = $_.Trim() -split '\|'
                    if ($parts.Count -ge 2) {
                        $objs += @{ name = $parts[0]; type = $parts[1] }
                    }
                }
                Write-Log "Schema tables: $($objs.Count) objetos encontrados" "Success"
                Send-Response $resp @{ success = $true; owner = $owner; tables = $objs }
            } catch {
                Write-Log "Erro /schema-tables: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/schema-columns" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data  = Read-JsonBody -Request $req
                $owner = $data.owner
                $table = $data.table

                if (-not $owner -or -not $table) {
                    Send-Response $resp @{ success = $false; error = "Campos 'owner' e 'table' obrigatorios" } 400
                    continue
                }

                $owner = ($owner -replace '[^A-Za-z0-9_]', '').ToUpper()
                $table = ($table -replace '[^A-Za-z0-9_]', '').ToUpper()

                if (-not $owner -or -not $table) {
                    Send-Response $resp @{ success = $false; error = "Owner ou table invalidos" } 400
                    continue
                }

                Write-Log "Schema columns: $owner.$table" "Info"

                # Saida: NOME_COL|TIPO(TAM)|N|default
                $plsql = @"
BEGIN
  FOR r IN (
    SELECT column_name,
           data_type ||
           CASE WHEN data_type IN ('VARCHAR2','CHAR','NVARCHAR2')
                THEN '('||data_length||')'
                WHEN data_type = 'NUMBER' AND data_precision IS NOT NULL
                THEN '('||data_precision||','||NVL(data_scale,0)||')'
                ELSE '' END                         AS full_type,
           nullable,
           NVL(TRIM(TO_CHAR(data_default)), '')     AS dflt
    FROM   all_tab_columns
    WHERE  owner      = '$owner'
    AND    table_name = '$table'
    ORDER BY column_id
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.column_name || '|' || r.full_type || '|' || r.nullable || '|' || r.dflt);
  END LOOP;
END;
"@
                $result = Invoke-SchemaQuery -PlSql $plsql

                if (-not $result.success) {
                    Send-Response $resp @{ success = $false; error = $result.error }
                    continue
                }

                $columns = @()
                foreach ($line in ($result.lines | Where-Object { $_.Trim() -ne '' })) {
                    $parts = $line -split '\|', 4
                    if ($parts.Count -ge 3) {
                        $columns += @{
                            name     = $parts[0].Trim()
                            type     = $parts[1].Trim()
                            nullable = $parts[2].Trim()
                            default  = if ($parts.Count -gt 3) { $parts[3].Trim() } else { '' }
                        }
                    }
                }

                Write-Log "Schema columns: $($columns.Count) colunas em $owner.$table" "Success"
                Send-Response $resp @{ success = $true; owner = $owner; table = $table; columns = $columns }
            } catch {
                Write-Log "Erro /schema-columns: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/schema-source" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data  = Read-JsonBody -Request $req
                $owner = $data.owner
                $name  = $data.name
                $type  = $data.type

                if (-not $owner -or -not $name -or -not $type) {
                    Send-Response $resp @{ success = $false; error = "Campos 'owner', 'name' e 'type' obrigatorios" } 400
                    continue
                }

                $owner = ($owner -replace '[^A-Za-z0-9_]', '').ToUpper()
                $name  = ($name -replace '[^A-Za-z0-9_#$]', '').ToUpper()
                $type  = ($type -replace '[^A-Za-z_ ]', '').ToUpper()

                Write-Log "Schema source: $owner.$name ($type)" "Info"

                $plsql = @"
BEGIN
  DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'SQLTERMINATOR', true);
  DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'PRETTY', true);
  DBMS_OUTPUT.PUT_LINE(DBMS_METADATA.GET_DDL('$type', '$name', '$owner'));
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERRO: ' || SQLERRM);
END;
"@
                $result = Invoke-SchemaQuery -PlSql $plsql

                if (-not $result.success) {
                    Send-Response $resp @{ success = $false; error = $result.error }
                    continue
                }

                $sourceCode = $result.lines -join "`n"
                Send-Response $resp @{ success = $true; owner = $owner; name = $name; type = $type; source = $sourceCode }
            } catch {
                Write-Log "Erro /schema-source: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }
        if ($path -eq "/schema-columns-batch" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                $tablesParam = $data.tables

                if (-not $tablesParam -or $tablesParam.Count -eq 0) {
                    Send-Response $resp @{ success = $false; error = "Campo 'tables' obrigatorio e deve ser um array" } 400
                    continue
                }

                Write-Log "Schema columns batch: $($tablesParam.Count) tabelas" "Info"

                # Cria um in_list seguro para as queries (apenas [A-Za-z0-9_] e agrupa por owner)
                $ownerTableMap = @{}
                foreach ($t in $tablesParam) {
                    $o = ($t.owner -replace '[^A-Za-z0-9_]', '').ToUpper()
                    $n = ($t.table -replace '[^A-Za-z0-9_]', '').ToUpper()
                    if ($o -and $n) {
                        if (-not $ownerTableMap[$o]) { $ownerTableMap[$o] = @() }
                        $ownerTableMap[$o] += $n
                    }
                }

                if ($ownerTableMap.Keys.Count -eq 0) {
                    Send-Response $resp @{ success = $false; error = "Nenhuma tabela valida fornecida" } 400
                    continue
                }

                # Monta os predicados WHERE dinamicamente
                $whereClauses = @()
                foreach ($o in $ownerTableMap.Keys) {
                    $tbls = $ownerTableMap[$o] | Select-Object -Unique
                    $inList = ($tbls | ForEach-Object { "'$_'" }) -join ","
                    $whereClauses += "(owner = '$o' AND table_name IN ($inList))"
                }
                $whereSql = $whereClauses -join " OR "

                # Saida: OWNER|NOME_TABELA|NOME_COL|TIPO(TAM)|N|default
                $plsql = @"
BEGIN
  FOR r IN (
    SELECT owner, table_name, column_name,
           data_type ||
           CASE WHEN data_type IN ('VARCHAR2','CHAR','NVARCHAR2')
                THEN '('||data_length||')'
                WHEN data_type = 'NUMBER' AND data_precision IS NOT NULL
                THEN '('||data_precision||','||NVL(data_scale,0)||')'
                ELSE '' END                         AS full_type,
           nullable,
           NVL(TRIM(TO_CHAR(data_default)), '')     AS dflt
    FROM   all_tab_columns
    WHERE  ($whereSql)
    ORDER BY owner, table_name, column_id
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.owner || '|' || r.table_name || '|' || r.column_name || '|' || r.full_type || '|' || r.nullable || '|' || r.dflt);
  END LOOP;
END;
"@
                $result = Invoke-SchemaQuery -PlSql $plsql

                if (-not $result.success) {
                    Send-Response $resp @{ success = $false; error = $result.error }
                    continue
                }

                $resultsByTable = @{}
                foreach ($line in ($result.lines | Where-Object { $_.Trim() -ne '' })) {
                    $parts = $line -split '\|', 6
                    if ($parts.Count -ge 5) {
                        $o = $parts[0].Trim()
                        $t = $parts[1].Trim()
                        $key = "$o.$t"
                        if (-not $resultsByTable[$key]) { $resultsByTable[$key] = @() }

                        $resultsByTable[$key] += @{
                            name     = $parts[2].Trim()
                            type     = $parts[3].Trim()
                            nullable = $parts[4].Trim()
                            default  = if ($parts.Count -gt 5) { $parts[5].Trim() } else { '' }
                        }
                    }
                }

                Write-Log "Schema columns batch concluido." "Success"
                Send-Response $resp @{ success = $true; results = $resultsByTable }
            } catch {
                Write-Log "Erro /schema-columns-batch: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── RAG Search ────────────────────────────────────────────────
        if ($path -eq "/rag-search" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) { Send-Response $resp @{ success = $false; error = $allowed.error } 403; continue }

                $data  = Read-JsonBody -Request $req
                $query = if ($data.query) { $data.query.ToLower() } else { "" }
                $topN  = if ($data.top)   { [int]$data.top }        else { 5 }

                $kbPath = Join-Path $ScriptDir "knowledge.json"
                if (-not (Test-Path $kbPath)) {
                    Send-Response $resp @{ success = $false; error = "knowledge.json nao encontrado" }
                    continue
                }

                $kb = Get-Content $kbPath -Encoding UTF8 -Raw | ConvertFrom-Json

                # Tokeniza query
                $queryTokens = ($query -split '\s+|,') | Where-Object { $_.Length -gt 2 }

                # Pontua cada entrada por relevância
                $scored = @()
                foreach ($entry in $kb) {
                    $score = 0
                    $titleLow   = $entry.title.ToLower()
                    $contentLow = $entry.content.ToLower()
                    $tagsLow    = ($entry.tags -join ' ').ToLower()

                    foreach ($token in $queryTokens) {
                        if ($tagsLow    -match [regex]::Escape($token)) { $score += 3 }
                        if ($titleLow   -match [regex]::Escape($token)) { $score += 2 }
                        if ($contentLow -match [regex]::Escape($token)) { $score += 1 }
                    }

                    if ($score -gt 0) {
                        $scored += @{ score = $score; entry = $entry }
                    }
                }

                $results = ($scored | Sort-Object { $_.score } -Descending | Select-Object -First $topN) |
                           ForEach-Object {
                               @{
                                   id      = $_.entry.id
                                   title   = $_.entry.title
                                   content = $_.entry.content
                                   score   = $_.score
                               }
                           }

                Write-Log "RAG: query='$query' → $($results.Count) resultados" "Info"
                Send-Response $resp @{ success = $true; query = $query; results = @($results) }

            } catch {
                Write-Log "Erro /rag-search: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── MCP Context ───────────────────────────────────────────────
        if ($path -eq "/mcp-context" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) { Send-Response $resp @{ success = $false; error = $allowed.error } 403; continue }

                $data  = Read-JsonBody -Request $req
                $appId = if ($data.appId) { [int]$data.appId } else { 0 }

                $config = Load-Env
                $context = @{
                    timestamp   = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')
                    serverReady = $true
                    knowledgeEntries = 0
                    pages      = @()
                    recentSQL  = @()
                }

                # Conta entradas do knowledge.json
                $kbPath = Join-Path $ScriptDir "knowledge.json"
                if (Test-Path $kbPath) {
                    $kb = Get-Content $kbPath -Encoding UTF8 -Raw | ConvertFrom-Json
                    $context.knowledgeEntries = $kb.Count
                }

                # SQL recentes executados com sucesso
                $scriptsDir = Join-Path $ScriptDir "scripts"
                if (Test-Path $scriptsDir) {
                    $recentFiles = Get-ChildItem "$scriptsDir\forge_success_*.json" -ErrorAction SilentlyContinue |
                                   Sort-Object LastWriteTime -Descending |
                                   Select-Object -First 5
                    foreach ($f in $recentFiles) {
                        $item = Get-Content $f.FullName -Encoding UTF8 -Raw | ConvertFrom-Json
                        $context.recentSQL += @{
                            timestamp = $item.timestamp
                            page      = $item.page
                            lines     = $item.lines
                            preview   = $item.preview
                        }
                    }
                }

                # Páginas do app (se banco disponível e appId fornecido)
                if ($appId -gt 0 -and $config.DB_CONNECTION -and $config.SQLCL_PATH) {
                    $plsql = @"
BEGIN
  FOR r IN (
    SELECT page_id, page_name
    FROM   apex_application_pages
    WHERE  application_id = $appId
    ORDER BY page_id
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(TO_CHAR(r.page_id) || '|' || r.page_name);
  END LOOP;
END;
"@
                    $qResult = Invoke-SchemaQuery -PlSql $plsql
                    if ($qResult.success) {
                        $context.pages = @($qResult.lines | Where-Object { $_ -match '\|' } | ForEach-Object {
                            $parts = $_ -split '\|', 2
                            @{ id = $parts[0].Trim(); name = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' } }
                        })
                    }
                }

                Write-Log "MCP context: $($context.pages.Count) paginas, $($context.knowledgeEntries) KB entries" "Info"
                Send-Response $resp @{ success = $true; context = $context }

            } catch {
                Write-Log "Erro /mcp-context: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── RAG Store (salvar SQL bem-sucedido) ───────────────────────
        if ($path -eq "/rag-store" -and $method -eq "POST") {
            try {
                $data = Read-JsonBody -Request $req
                if (-not $data.sql) { Send-Response $resp @{ success = $false; error = "Campo sql obrigatorio" } 400; continue }

                $scriptsDir = Join-Path $ScriptDir "scripts"
                if (-not (Test-Path $scriptsDir)) {
                    New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
                }

                $stamp    = Get-Date -Format 'yyyyMMdd_HHmmss'
                $outFile  = Join-Path $scriptsDir "forge_success_$stamp.json"
                $preview  = ($data.sql -split "`n" | Select-Object -First 5) -join "`n"
                $entry = @{
                    timestamp = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')
                    page      = if ($data.page)    { $data.page }    else { "?" }
                    appId     = if ($data.appId)   { $data.appId }   else { "?" }
                    lines     = ($data.sql -split "`n").Count
                    preview   = $preview
                    tags      = if ($data.tags)    { $data.tags }    else { @() }
                }
                $enc = New-Object System.Text.UTF8Encoding $false
                [System.IO.File]::WriteAllText($outFile, ($entry | ConvertTo-Json -Depth 5), $enc)

                Write-Log "RAG stored: $($entry.lines) linhas (pagina $($entry.page))" "Success"
                Send-Response $resp @{ success = $true; file = (Split-Path $outFile -Leaf) }

            } catch {
                Write-Log "Erro /rag-store: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── Codex CLI Endpoint ──────────────────────────────────────────────
        if ($path -eq "/ai-codex" -and $method -eq "POST") {
            try {
                $allowed = Test-RequestAllowed -Request $req
                if (-not $allowed.ok) {
                    Send-Response $resp @{ success = $false; error = $allowed.error } 403
                    continue
                }

                $data = Read-JsonBody -Request $req
                $system = if ($data.system) { $data.system } else { "" }
                $message = if ($data.message) { $data.message } else { "" }

                if (-not $message) {
                    Send-Response $resp @{ success = $false; error = "Prompt vazio" } 400
                    continue
                }

                Write-Log "Iniciando chamada ao Codex CLI local" "Info"

                # Cria arquivo temporario com o prompt inteiro (system + message)
                $tempPrompt = Join-Path $ScriptDir ".codex_prompt_temp.txt"
                $tempOut = Join-Path $ScriptDir ".codex_out_temp.txt"
                
                $fullPrompt = "$system`n`n$message"
                $enc = New-Object System.Text.UTF8Encoding $false
                [System.IO.File]::WriteAllText($tempPrompt, $fullPrompt, $enc)

                # Roda o Codex CLI
                # Usa -a never (para nao travar), -s read-only, e -o para capturar output.
                # Como precisamos injetar o arquivo tempPrompt via stdin, usamos cmd.exe /c
                
                $cmdArgs = "/c codex exec -a never -s read-only -o `"$tempOut`" - < `"$tempPrompt`""
                
                $procInfo = New-Object System.Diagnostics.ProcessStartInfo
                $procInfo.FileName = "cmd.exe"
                $procInfo.Arguments = $cmdArgs
                $procInfo.RedirectStandardOutput = $true
                $procInfo.RedirectStandardError = $true
                $procInfo.UseShellExecute = $false
                $procInfo.CreateNoWindow = $true
                $procInfo.WorkingDirectory = $ScriptDir
                
                # Vamos forçar encoding UTF8
                $procInfo.StandardOutputEncoding = [System.Text.Encoding]::UTF8
                $procInfo.StandardErrorEncoding = [System.Text.Encoding]::UTF8

                $proc = New-Object System.Diagnostics.Process
                $proc.StartInfo = $procInfo
                
                # Timeout dinamico, ou 5 mins padrao
                $timeoutSecs = if ($data.timeout) { [int]$data.timeout } else { 300 }

                $sw = [System.Diagnostics.Stopwatch]::StartNew()
                [void]$proc.Start()
                
                # Espera com timeout
                $exited = $proc.WaitForExit($timeoutSecs * 1000)
                
                if (-not $exited) {
                    $proc.Kill()
                    throw "Codex CLI demorou mais que $timeoutSecs segundos e foi cancelado."
                }
                
                $sw.Stop()
                
                # Log outputs caso tenha erro, mas Codex normalmente cospe progress bar no stderr
                $err = $proc.StandardError.ReadToEnd()
                if ($proc.ExitCode -ne 0) {
                    Write-Log "Codex CLI stderr: $err" "Warning"
                }

                if (Test-Path $tempOut) {
                    $aiResponse = Get-Content $tempOut -Encoding UTF8 -Raw
                    # Remove trailing newlines ou null
                    if ($aiResponse) { $aiResponse = $aiResponse.Trim() }
                    
                    Write-Log "Codex CLI respondeu em $([math]::Round($sw.Elapsed.TotalSeconds,1))s ($($aiResponse.Length) chars)" "Success"
                    Send-Response $resp @{ success = $true; text = $aiResponse }
                } else {
                    Write-Log "Codex CLI stderr (Sem arquivo de saida): $err" "Error"
                    Send-Response $resp @{ success = $false; error = "Codex CLI nao gerou arquivo de resposta." } 500
                }

                # Limpa temp
                Remove-Item $tempPrompt -ErrorAction SilentlyContinue
                Remove-Item $tempOut -ErrorAction SilentlyContinue

            } catch {
                Write-Log "Erro /ai-codex: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── Saved Prompts ──────────────────────────────────────────────────
        if ($path -eq "/save-prompt" -and $method -eq "POST") {
            try {
                $data = Read-JsonBody -Request $req
                if (-not $data.prompt -or -not $data.title) { 
                    Send-Response $resp @{ success = $false; error = "Campos 'title' e 'prompt' obrigatorios" } 400
                    continue 
                }

                $promptsFile = Join-Path $ScriptDir "saved_prompts.json"
                $prompts = @()
                if (Test-Path $promptsFile) {
                    $prompts = Get-Content $promptsFile -Encoding UTF8 -Raw | ConvertFrom-Json
                }

                $newPrompt = @{
                    id        = [guid]::NewGuid().ToString()
                    timestamp = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')
                    title     = $data.title
                    prompt    = $data.prompt
                }
                
                # Add array explicitly in case $prompts is a single object or empty
                $prompts = @($prompts) + $newPrompt

                $enc = New-Object System.Text.UTF8Encoding $false
                [System.IO.File]::WriteAllText($promptsFile, ($prompts | ConvertTo-Json -Depth 5), $enc)

                Write-Log "Prompt salvo: '$($data.title)'" "Success"
                Send-Response $resp @{ success = $true; prompt = $newPrompt }
            } catch {
                Write-Log "Erro /save-prompt: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        if ($path -eq "/list-prompts" -and $method -eq "GET") {
            try {
                $promptsFile = Join-Path $ScriptDir "saved_prompts.json"
                $prompts = @()
                if (Test-Path $promptsFile) {
                    $prompts = Get-Content $promptsFile -Encoding UTF8 -Raw | ConvertFrom-Json
                }
                Send-Response $resp @{ success = $true; prompts = @($prompts) }
            } catch {
                Write-Log "Erro /list-prompts: $_" "Error"
                Send-Response $resp @{ success = $false; error = $_.Exception.Message } 500
            }
            continue
        }

        # ── Static files (HTML, CSS, JS) ──────────────────────────────
        if ($method -eq "GET") {
            $filePath = if ($path -eq "/" -or $path -eq "/index.html") {
                Join-Path $ScriptDir "index.html"
            } else {
                Join-Path $ScriptDir ($path.TrimStart('/').Replace('/', '\'))
            }

            if (Test-Path $filePath -PathType Leaf) {
                $ext  = [System.IO.Path]::GetExtension($filePath).ToLower()
                $mime = switch ($ext) {
                    ".html" { "text/html; charset=utf-8" }
                    ".css"  { "text/css; charset=utf-8" }
                    ".js"   { "application/javascript; charset=utf-8" }
                    ".json" { "application/json; charset=utf-8" }
                    default { "application/octet-stream" }
                }
                $bytes = [System.IO.File]::ReadAllBytes($filePath)
                $resp.StatusCode      = 200
                $resp.ContentType     = $mime
                $resp.ContentLength64 = $bytes.Length
                $resp.Headers.Add("Access-Control-Allow-Origin", "*")
                $resp.OutputStream.Write($bytes, 0, $bytes.Length)
                $resp.OutputStream.Close()
                Write-Log "Static: $path ($($bytes.Length) bytes)" "Info"
                continue
            }
        }

        Send-Response $resp @{ error = "Rota nao encontrada: $path" } 404
    }
} finally {
    $listener.Stop()
    Write-Log "Servidor encerrado." "Warning"
}
