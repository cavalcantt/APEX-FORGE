// APEX Forge Content Script

// Verifica se é uma página APEX pelo DOM
const isApex = document.getElementById('pFlowId') !== null || document.querySelector('form#wwvFlowForm') !== null;

if (isApex) {
    console.log("APEX Forge Extension: Iniciando injeção...");
    
    // Aguarda um instante para garantir
    setTimeout(() => {
        // Cria o botão flutuante com estilos inline para garantir que apareça mesmo sem CSS
        const fab = document.createElement('div');
        fab.id = 'af-fab';
        fab.innerHTML = '⚡';
        fab.title = 'Abrir APEX Forge';
        fab.style.cssText = 'position:fixed;bottom:20px;right:20px;width:50px;height:50px;background-color:#6366f1;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.5);cursor:pointer;z-index:2147483647;font-size:24px;user-select:none;font-family:sans-serif;transition:right 0.3s ease;';

        // Cria o painel lateral
        const drawer = document.createElement('div');
        drawer.id = 'af-drawer';
        drawer.style.cssText = 'position:fixed;top:0;right:-450px;width:450px;height:100vh;background-color:#0d1117;box-shadow:-5px 0 15px rgba(0,0,0,0.5);z-index:2147483646;transition:right 0.3s ease;display:flex;flex-direction:column;';

        // Cria o iframe carregando o servidor local
        const iframe = document.createElement('iframe');
        iframe.id = 'af-iframe';
        iframe.src = 'http://localhost:3007/'; // O seu server.ps1
        iframe.style.cssText = 'width:100%;height:100%;border:none;';
        
        drawer.appendChild(iframe);
        document.body.appendChild(fab);
        document.body.appendChild(drawer);

        console.log("APEX Forge Extension: Elementos DOM injetados com sucesso.");

        // Alterna o painel ao clicar no botão
        fab.addEventListener('click', () => {
          const isOpen = drawer.style.right === '0px';
          drawer.style.right = isOpen ? '-450px' : '0px';
          fab.style.right = isOpen ? '20px' : '470px';
        });
        
        // Listener para mensagens do Iframe (APEX Forge local)
        window.addEventListener('message', (event) => {
          if (event.origin !== 'http://localhost:3007') return;

          const data = event.data;
          
          if (data.type === 'GET_APEX_CONTEXT') {
            const params = new URLSearchParams(window.location.search);
            const pValue = params.get('p') || '';
            const parts = pValue.split(':');
            
            let appId = '';
            let pageId = '';
            let session = '';
            
            // Tenta pegar do DOM (100% garantido para Runtime e Builder)
            const domApp = document.getElementById('pFlowId');
            const domPage = document.getElementById('pFlowStepId');
            const domSession = document.getElementById('pInstance');
            
            if (domApp) appId = domApp.value;
            if (domPage) pageId = domPage.value;
            if (domSession) session = domSession.value;

            // No Page Designer os inputs do DOM são 4000 e 4500, precisamos da app "real"
            if (parts.length >= 3 && parts[0] === '4000' && parts[1] === '4500') {
                session = parts[2] || session;
                if (parts.length >= 8 && parts[6].includes('FB_FLOW_ID')) {
                   const names = parts[6].split(',');
                   const values = parts[7].split(',');
                   const idxApp = names.indexOf('FB_FLOW_ID');
                   const idxPage = names.indexOf('FB_FLOW_PAGE_ID');
                   if (idxApp > -1) appId = values[idxApp];
                   if (idxPage > -1) pageId = values[idxPage];
                }
            } else if (parts.length >= 3 && !appId) {
                appId = parts[0];
                pageId = parts[1];
                session = parts[2];
            }
            
            // Friendly URLs
            if (!session && params.has('session')) {
                session = params.get('session');
            }

            iframe.contentWindow.postMessage({
              type: 'APEX_CONTEXT_RESPONSE',
              url: window.location.href,
              appId: appId,
              pageId: pageId,
              session: session
            }, 'http://localhost:3007');
          }
        });
    }, 1000);
}
